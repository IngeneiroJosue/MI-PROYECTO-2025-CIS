# Details

Date : 2025-06-06 12:07:51

Directory c:\\Users\\LEnovo\\OneDrive\\Documentos\\NetBeansProjects\\MinsaFlatLaf

Total : 66 files,  5660 codes, 517 comments, 550 blanks, all 6727 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [build.xml](/build.xml) | XML | 5 | 68 | 1 | 74 |
| [build/classes/Dao/Conexion.class](/build/classes/Dao/Conexion.class) | Java | 17 | 0 | 0 | 17 |
| [build/classes/Dao/UsuarioDAO.class](/build/classes/Dao/UsuarioDAO.class) | Java | 39 | 0 | 0 | 39 |
| [build/classes/Modelo/Atencion.class](/build/classes/Modelo/Atencion.class) | Java | 11 | 0 | 0 | 11 |
| [build/classes/Modelo/Participante.class](/build/classes/Modelo/Participante.class) | Java | 8 | 0 | 0 | 8 |
| [build/classes/Modelo/Programa.class](/build/classes/Modelo/Programa.class) | Java | 11 | 0 | 0 | 11 |
| [build/classes/Modelo/Usuario.class](/build/classes/Modelo/Usuario.class) | Java | 9 | 0 | 0 | 9 |
| [build/classes/Vista/AtencionPanel$1.class](/build/classes/Vista/AtencionPanel$1.class) | Java | 9 | 0 | 0 | 9 |
| [build/classes/Vista/AtencionPanel$2.class](/build/classes/Vista/AtencionPanel$2.class) | Java | 23 | 0 | 0 | 23 |
| [build/classes/Vista/AtencionView$1.class](/build/classes/Vista/AtencionView$1.class) | Java | 9 | 0 | 0 | 9 |
| [build/classes/Vista/AtencionView$2.class](/build/classes/Vista/AtencionView$2.class) | Java | 23 | 0 | 0 | 23 |
| [build/classes/Vista/AtencionView$ModernTableCellRenderer.class](/build/classes/Vista/AtencionView$ModernTableCellRenderer.class) | Java | 21 | 0 | 1 | 22 |
| [build/classes/Vista/AtencionView.class](/build/classes/Vista/AtencionView.class) | Java | 101 | 0 | 0 | 101 |
| [build/classes/Vista/ConfiguracionPanel.class](/build/classes/Vista/ConfiguracionPanel.class) | Java | 73 | 0 | 0 | 73 |
| [build/classes/Vista/DashboardFrame$1.class](/build/classes/Vista/DashboardFrame$1.class) | Java | 15 | 0 | 0 | 15 |
| [build/classes/Vista/DashboardFrame.class](/build/classes/Vista/DashboardFrame.class) | Java | 189 | 0 | 1 | 190 |
| [build/classes/Vista/FormularioAtencion.class](/build/classes/Vista/FormularioAtencion.class) | Java | 118 | 0 | 0 | 118 |
| [build/classes/Vista/Login$1.class](/build/classes/Vista/Login$1.class) | Java | 21 | 0 | 0 | 21 |
| [build/classes/Vista/Login$2.class](/build/classes/Vista/Login$2.class) | Java | 18 | 0 | 0 | 18 |
| [build/classes/Vista/Login$3.class](/build/classes/Vista/Login$3.class) | Java | 23 | 0 | 0 | 23 |
| [build/classes/Vista/Login.class](/build/classes/Vista/Login.class) | Java | 110 | 0 | 0 | 110 |
| [build/classes/Vista/LoginForm$1.class](/build/classes/Vista/LoginForm$1.class) | Java | 19 | 0 | 0 | 19 |
| [build/classes/Vista/LoginForm.class](/build/classes/Vista/LoginForm.class) | Java | 112 | 6 | 0 | 118 |
| [build/classes/Vista/NotifficacionButton.class](/build/classes/Vista/NotifficacionButton.class) | Java | 5 | 0 | 0 | 5 |
| [build/classes/Vista/NotificacionView.class](/build/classes/Vista/NotificacionView.class) | Java | 56 | 0 | 0 | 56 |
| [build/classes/Vista/ParticipanteForm.class](/build/classes/Vista/ParticipanteForm.class) | Java | 78 | 0 | 0 | 78 |
| [build/classes/Vista/ParticipanteView.class](/build/classes/Vista/ParticipanteView.class) | Java | 64 | 0 | 0 | 64 |
| [build/classes/Vista/ProgramaForm.class](/build/classes/Vista/ProgramaForm.class) | Java | 69 | 0 | 0 | 69 |
| [build/classes/Vista/ProgramaPanel$1.class](/build/classes/Vista/ProgramaPanel$1.class) | Java | 7 | 0 | 0 | 7 |
| [build/classes/Vista/ProgramaPanel$2.class](/build/classes/Vista/ProgramaPanel$2.class) | Java | 14 | 0 | 0 | 14 |
| [build/classes/Vista/ProgramaView$1.class](/build/classes/Vista/ProgramaView$1.class) | Java | 7 | 0 | 0 | 7 |
| [build/classes/Vista/ProgramaView$2.class](/build/classes/Vista/ProgramaView$2.class) | Java | 14 | 0 | 0 | 14 |
| [build/classes/Vista/ProgramaView.class](/build/classes/Vista/ProgramaView.class) | Java | 109 | 13 | 1 | 123 |
| [build/classes/Vista/UsuarioForm.class](/build/classes/Vista/UsuarioForm.class) | Java | 77 | 0 | 0 | 77 |
| [build/classes/Vista/UsuarioView$1.class](/build/classes/Vista/UsuarioView$1.class) | Java | 9 | 0 | 0 | 9 |
| [build/classes/Vista/UsuarioView$2.class](/build/classes/Vista/UsuarioView$2.class) | Java | 15 | 3 | 0 | 18 |
| [build/classes/Vista/UsuarioView$3.class](/build/classes/Vista/UsuarioView$3.class) | Java | 13 | 0 | 0 | 13 |
| [build/classes/Vista/UsuarioView$4.class](/build/classes/Vista/UsuarioView$4.class) | Java | 16 | 0 | 0 | 16 |
| [build/classes/Vista/UsuarioView$AccionesCellRenderer.class](/build/classes/Vista/UsuarioView$AccionesCellRenderer.class) | Java | 44 | 0 | 0 | 44 |
| [build/classes/Vista/UsuarioView$EstadoCellRenderer.class](/build/classes/Vista/UsuarioView$EstadoCellRenderer.class) | Java | 25 | 0 | 0 | 25 |
| [build/classes/Vista/UsuarioView.class](/build/classes/Vista/UsuarioView.class) | Java | 225 | 0 | 0 | 225 |
| [nbproject/build-impl.xml](/nbproject/build-impl.xml) | XML | 1,633 | 138 | 1 | 1,772 |
| [nbproject/genfiles.properties](/nbproject/genfiles.properties) | Java Properties | 6 | 2 | 1 | 9 |
| [nbproject/private/private.properties](/nbproject/private/private.properties) | Java Properties | 2 | 0 | 1 | 3 |
| [nbproject/private/private.xml](/nbproject/private/private.xml) | XML | 11 | 0 | 1 | 12 |
| [nbproject/project.properties](/nbproject/project.properties) | Java Properties | 85 | 12 | 1 | 98 |
| [nbproject/project.xml](/nbproject/project.xml) | XML | 15 | 0 | 1 | 16 |
| [src/Dao/Conexion.java](/src/Dao/Conexion.java) | Java | 24 | 8 | 7 | 39 |
| [src/Dao/UsuarioDAO.java](/src/Dao/UsuarioDAO.java) | Java | 72 | 12 | 27 | 111 |
| [src/Modelo/Atencion.java](/src/Modelo/Atencion.java) | Java | 16 | 5 | 4 | 25 |
| [src/Modelo/Participante.java](/src/Modelo/Participante.java) | Java | 34 | 9 | 4 | 47 |
| [src/Modelo/Programa.java](/src/Modelo/Programa.java) | Java | 15 | 9 | 5 | 29 |
| [src/Modelo/Usuario.java](/src/Modelo/Usuario.java) | Java | 21 | 5 | 3 | 29 |
| [src/Vista/AtencionView.java](/src/Vista/AtencionView.java) | Java | 167 | 34 | 35 | 236 |
| [src/Vista/ConfiguracionPanel.java](/src/Vista/ConfiguracionPanel.java) | Java | 64 | 9 | 22 | 95 |
| [src/Vista/DashboardFrame.java](/src/Vista/DashboardFrame.java) | Java | 352 | 38 | 101 | 491 |
| [src/Vista/FormularioAtencion.java](/src/Vista/FormularioAtencion.java) | Java | 145 | 21 | 46 | 212 |
| [src/Vista/Login.java](/src/Vista/Login.java) | Java | 157 | 14 | 41 | 212 |
| [src/Vista/NotificacionView.java](/src/Vista/NotificacionView.java) | Java | 69 | 8 | 14 | 91 |
| [src/Vista/ParticipanteForm.java](/src/Vista/ParticipanteForm.java) | Java | 107 | 8 | 27 | 142 |
| [src/Vista/ParticipanteView.java](/src/Vista/ParticipanteView.java) | Java | 119 | 11 | 36 | 166 |
| [src/Vista/ProgramaForm.java](/src/Vista/ProgramaForm.java) | Java | 69 | 10 | 19 | 98 |
| [src/Vista/ProgramaView.java](/src/Vista/ProgramaView.java) | Java | 153 | 13 | 33 | 199 |
| [src/Vista/RegistroUsuario.java](/src/Vista/RegistroUsuario.java) | Java | 1 | 8 | 4 | 13 |
| [src/Vista/UsuarioForm.java](/src/Vista/UsuarioForm.java) | Java | 74 | 10 | 20 | 104 |
| [src/Vista/UsuarioView.java](/src/Vista/UsuarioView.java) | Java | 418 | 43 | 92 | 553 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)
# Summary

Date : 2025-06-06 12:07:51

Directory c:\\Users\\LEnovo\\OneDrive\\Documentos\\NetBeansProjects\\MinsaFlatLaf

Total : 66 files,  5660 codes, 517 comments, 550 blanks, all 6727 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 59 | 3,903 | 297 | 543 | 4,743 |
| XML | 4 | 1,664 | 206 | 4 | 1,874 |
| Java Properties | 3 | 93 | 14 | 3 | 110 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 66 | 5,660 | 517 | 550 | 6,727 |
| . (Files) | 1 | 5 | 68 | 1 | 74 |
| build | 40 | 1,826 | 22 | 3 | 1,851 |
| build\\classes | 40 | 1,826 | 22 | 3 | 1,851 |
| build\\classes\\Dao | 2 | 56 | 0 | 0 | 56 |
| build\\classes\\Modelo | 4 | 39 | 0 | 0 | 39 |
| build\\classes\\Vista | 34 | 1,731 | 22 | 3 | 1,756 |
| nbproject | 6 | 1,752 | 152 | 6 | 1,910 |
| nbproject (Files) | 4 | 1,739 | 152 | 4 | 1,895 |
| nbproject\\private | 2 | 13 | 0 | 2 | 15 |
| src | 19 | 2,077 | 275 | 540 | 2,892 |
| src\\Dao | 2 | 96 | 20 | 34 | 150 |
| src\\Modelo | 4 | 86 | 28 | 16 | 130 |
| src\\Vista | 13 | 1,895 | 227 | 490 | 2,612 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)
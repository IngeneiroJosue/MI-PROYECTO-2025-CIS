# Diff Details

Date : 2025-06-06 12:07:51

Directory c:\\Users\\LEnovo\\OneDrive\\Documentos\\NetBeansProjects\\MinsaFlatLaf

Total : 0 files,  0 codes, 0 comments, 0 blanks, all 0 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details
# Diff Summary

Date : 2025-06-13 12:31:14

Directory c:\\Users\\LEnovo\\OneDrive\\Documentos\\NetBeansProjects\\MinsaFlatLaf

Total : 44 files,  430 codes, -33 comments, 66 blanks, all 463 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 42 | 420 | -33 | 66 | 453 |
| XML | 1 | 8 | 0 | 0 | 8 |
| Java Properties | 1 | 2 | 0 | 0 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 44 | 430 | -33 | 66 | 463 |
| build | 24 | 131 | -9 | -2 | 120 |
| build\\classes | 24 | 131 | -9 | -2 | 120 |
| build\\classes (Files) | 2 | 19 | 0 | 0 | 19 |
| build\\classes\\Dao | 5 | 113 | 0 | 0 | 113 |
| build\\classes\\Modelo | 1 | 1 | 0 | 0 | 1 |
| build\\classes\\Vista | 16 | -2 | -9 | -2 | -13 |
| nbproject | 2 | 10 | 0 | 0 | 10 |
| nbproject (Files) | 1 | 2 | 0 | 0 | 2 |
| nbproject\\private | 1 | 8 | 0 | 0 | 8 |
| src | 18 | 289 | -24 | 68 | 333 |
| src\\Dao | 5 | 250 | 32 | 62 | 344 |
| src\\Modelo | 2 | 5 | 0 | 2 | 7 |
| src\\Vista | 11 | 34 | -56 | 4 | -18 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)
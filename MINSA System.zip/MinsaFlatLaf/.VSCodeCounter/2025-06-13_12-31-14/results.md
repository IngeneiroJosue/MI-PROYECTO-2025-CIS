# Summary

Date : 2025-06-13 12:31:14

Directory c:\\Users\\LEnovo\\OneDrive\\Documentos\\NetBeansProjects\\MinsaFlatLaf

Total : 85 files,  6090 codes, 484 comments, 616 blanks, all 7190 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 78 | 4,323 | 264 | 609 | 5,196 |
| XML | 4 | 1,672 | 206 | 4 | 1,882 |
| Java Properties | 3 | 95 | 14 | 3 | 112 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 85 | 6,090 | 484 | 616 | 7,190 |
| . (Files) | 1 | 5 | 68 | 1 | 74 |
| build | 52 | 1,957 | 13 | 1 | 1,971 |
| build\\classes | 52 | 1,957 | 13 | 1 | 1,971 |
| build\\classes (Files) | 2 | 19 | 0 | 0 | 19 |
| build\\classes\\Dao | 7 | 169 | 0 | 0 | 169 |
| build\\classes\\Modelo | 4 | 40 | 0 | 0 | 40 |
| build\\classes\\Vista | 39 | 1,729 | 13 | 1 | 1,743 |
| nbproject | 6 | 1,762 | 152 | 6 | 1,920 |
| nbproject (Files) | 4 | 1,741 | 152 | 4 | 1,897 |
| nbproject\\private | 2 | 21 | 0 | 2 | 23 |
| src | 26 | 2,366 | 251 | 608 | 3,225 |
| src\\Dao | 7 | 346 | 52 | 96 | 494 |
| src\\Modelo | 4 | 91 | 28 | 18 | 137 |
| src\\Vista | 15 | 1,929 | 171 | 494 | 2,594 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)
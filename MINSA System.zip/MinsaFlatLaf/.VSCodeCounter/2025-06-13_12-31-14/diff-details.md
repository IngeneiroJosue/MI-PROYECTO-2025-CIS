# Diff Details

Date : 2025-06-13 12:31:14

Directory c:\\Users\\LEnovo\\OneDrive\\Documentos\\NetBeansProjects\\MinsaFlatLaf

Total : 44 files,  430 codes, -33 comments, 66 blanks, all 463 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [build/classes/Dao/ParticipanteDAO.class](/build/classes/Dao/ParticipanteDAO.class) | Java | 47 | 0 | 0 | 47 |
| [build/classes/Dao/ProgramaDAO.class](/build/classes/Dao/ProgramaDAO.class) | Java | 8 | 0 | 0 | 8 |
| [build/classes/Dao/ProgramaDAOImpl.class](/build/classes/Dao/ProgramaDAOImpl.class) | Java | 34 | 0 | 0 | 34 |
| [build/classes/Dao/RolAccesoDAO.class](/build/classes/Dao/RolAccesoDAO.class) | Java | 4 | 0 | 0 | 4 |
| [build/classes/Dao/RolAccesoDAOImpl.class](/build/classes/Dao/RolAccesoDAOImpl.class) | Java | 20 | 0 | 0 | 20 |
| [build/classes/DashboardFrame$1.class](/build/classes/DashboardFrame$1.class) | Java | 12 | 0 | 0 | 12 |
| [build/classes/Modelo/Participante.class](/build/classes/Modelo/Participante.class) | Java | 1 | 0 | 0 | 1 |
| [build/classes/ProgramaView$1.class](/build/classes/ProgramaView$1.class) | Java | 7 | 0 | 0 | 7 |
| [build/classes/Vista/AtencionView.class](/build/classes/Vista/AtencionView.class) | Java | 5 | 0 | 0 | 5 |
| [build/classes/Vista/DashboardFrame.class](/build/classes/Vista/DashboardFrame.class) | Java | 22 | 0 | -1 | 21 |
| [build/classes/Vista/FormularioAtencion.class](/build/classes/Vista/FormularioAtencion.class) | Java | -4 | 0 | 0 | -4 |
| [build/classes/Vista/InicioView.class](/build/classes/Vista/InicioView.class) | Java | 6 | 0 | 0 | 6 |
| [build/classes/Vista/Login.class](/build/classes/Vista/Login.class) | Java | 3 | 4 | 0 | 7 |
| [build/classes/Vista/ParticipanteForm.class](/build/classes/Vista/ParticipanteForm.class) | Java | -33 | 0 | 0 | -33 |
| [build/classes/Vista/ParticipanteView$1.class](/build/classes/Vista/ParticipanteView$1.class) | Java | 11 | 0 | 0 | 11 |
| [build/classes/Vista/ParticipanteView.class](/build/classes/Vista/ParticipanteView.class) | Java | 27 | 0 | 0 | 27 |
| [build/classes/Vista/ProgramaForm$FormListener.class](/build/classes/Vista/ProgramaForm$FormListener.class) | Java | 6 | 0 | 0 | 6 |
| [build/classes/Vista/ProgramaForm.class](/build/classes/Vista/ProgramaForm.class) | Java | 20 | 0 | 0 | 20 |
| [build/classes/Vista/ProgramaView$2.class](/build/classes/Vista/ProgramaView$2.class) | Java | 1 | 0 | 0 | 1 |
| [build/classes/Vista/ProgramaView$3.class](/build/classes/Vista/ProgramaView$3.class) | Java | 16 | 0 | 0 | 16 |
| [build/classes/Vista/ProgramaView.class](/build/classes/Vista/ProgramaView.class) | Java | -31 | -13 | -1 | -45 |
| [build/classes/Vista/ReportesView.class](/build/classes/Vista/ReportesView.class) | Java | 6 | 0 | 0 | 6 |
| [build/classes/Vista/UsuarioForm.class](/build/classes/Vista/UsuarioForm.class) | Java | -53 | 0 | 0 | -53 |
| [build/classes/Vista/UsuarioView.class](/build/classes/Vista/UsuarioView.class) | Java | -4 | 0 | 0 | -4 |
| [nbproject/private/private.xml](/nbproject/private/private.xml) | XML | 8 | 0 | 0 | 8 |
| [nbproject/project.properties](/nbproject/project.properties) | Java Properties | 2 | 0 | 0 | 2 |
| [src/Dao/ParticipanteDAO.java](/src/Dao/ParticipanteDAO.java) | Java | 99 | 8 | 26 | 133 |
| [src/Dao/ProgramaDAO.java](/src/Dao/ProgramaDAO.java) | Java | 10 | 8 | 3 | 21 |
| [src/Dao/ProgramaDAOImpl.java](/src/Dao/ProgramaDAOImpl.java) | Java | 82 | 8 | 13 | 103 |
| [src/Dao/RolAccesoDAO.java](/src/Dao/RolAccesoDAO.java) | Java | 8 | 4 | 4 | 16 |
| [src/Dao/RolAccesoDAOImpl.java](/src/Dao/RolAccesoDAOImpl.java) | Java | 51 | 4 | 16 | 71 |
| [src/Modelo/Participante.java](/src/Modelo/Participante.java) | Java | 2 | 0 | 2 | 4 |
| [src/Modelo/Programa.java](/src/Modelo/Programa.java) | Java | 3 | 0 | 0 | 3 |
| [src/Vista/AtencionView.java](/src/Vista/AtencionView.java) | Java | 5 | -25 | 3 | -17 |
| [src/Vista/DashboardFrame.java](/src/Vista/DashboardFrame.java) | Java | 68 | -29 | 3 | 42 |
| [src/Vista/FormularioAtencion.java](/src/Vista/FormularioAtencion.java) | Java | -8 | -4 | -2 | -14 |
| [src/Vista/InicioView.java](/src/Vista/InicioView.java) | Java | 4 | 8 | 4 | 16 |
| [src/Vista/Login.java](/src/Vista/Login.java) | Java | 13 | 0 | 2 | 15 |
| [src/Vista/ParticipanteForm.java](/src/Vista/ParticipanteForm.java) | Java | -50 | 1 | -8 | -57 |
| [src/Vista/ParticipanteView.java](/src/Vista/ParticipanteView.java) | Java | -3 | 1 | -9 | -11 |
| [src/Vista/ProgramaForm.java](/src/Vista/ProgramaForm.java) | Java | 21 | -1 | 6 | 26 |
| [src/Vista/ProgramaView.java](/src/Vista/ProgramaView.java) | Java | -34 | -11 | -1 | -46 |
| [src/Vista/ReportesView.java](/src/Vista/ReportesView.java) | Java | 4 | 8 | 4 | 16 |
| [src/Vista/UsuarioForm.java](/src/Vista/UsuarioForm.java) | Java | 14 | -4 | 2 | 12 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details
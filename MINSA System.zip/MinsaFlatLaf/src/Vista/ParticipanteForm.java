/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */



import Modelo.Participante;
import Dao.ParticipanteDAO;

import javax.swing.*;
import java.awt.*;

public class ParticipanteForm extends JPanel {
    private JTextField txtNombre, txtApellido, txtEdad;
    private JComboBox<String> cmbSexo;
    private JButton btnAgregar, btnCancelar;
    private ParticipanteDAO dao = new ParticipanteDAO();
    private JDialog dialog;

    public ParticipanteForm(JDialog dialog) {
        this.dialog = dialog;
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        txtNombre = new JTextField();
        txtApellido = new JTextField();
        txtEdad = new JTextField();
        cmbSexo = new JComboBox<>(new String[]{"Masculino", "Femenino", "Otro"});

        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(txtNombre);
        formPanel.add(new JLabel("Apellido:"));
        formPanel.add(txtApellido);
        formPanel.add(new JLabel("Edad:"));
        formPanel.add(txtEdad);
        formPanel.add(new JLabel("Sexo:"));
        formPanel.add(cmbSexo);

        add(formPanel, BorderLayout.CENTER);

        btnAgregar = new JButton("Agregar");
        btnCancelar = new JButton("Cancelar");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnAgregar);
        buttonPanel.add(btnCancelar);
        add(buttonPanel, BorderLayout.SOUTH);

        // Eventos
        btnCancelar.addActionListener(e -> dialog.dispose());

        btnAgregar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            String apellido = txtApellido.getText().trim();
            String edadStr = txtEdad.getText().trim();
            String sexo = cmbSexo.getSelectedItem().toString();

            if (nombre.isEmpty() || apellido.isEmpty() || edadStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Completa todos los campos");
                return;
            }

            try {
                int edad = Integer.parseInt(edadStr);
                Participante p = new Participante();
                dao.agregar(p);
                JOptionPane.showMessageDialog(this, "Participante registrado correctamente");
                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Edad inválida");
            }
        });
    }
}


    
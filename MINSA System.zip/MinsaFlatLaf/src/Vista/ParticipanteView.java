/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */




import Modelo.Participante;
import Dao.ParticipanteDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ParticipanteView extends JPanel {
    private JTextField txtNombre, txtApellido, txtEdad;
    private JComboBox<String> cmbSexo;
    private JTable tblParticipantes;
    private JButton btnNuevo, btnAgregar, btnEliminar;

    private ParticipanteDAO dao = new ParticipanteDAO();
    private Participante participanteSeleccionado = null;
    private DefaultTableModel modelo;

    public ParticipanteView() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        UIManager.put("TextComponent.arc", 10);
        UIManager.put("Component.arc", 10);
        UIManager.put("Button.arc", 10);
        UIManager.put("ProgressBar.arc", 10);

        // --- Formulario ---
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.setBackground(Color.WHITE);

        txtNombre = new JTextField();
        txtApellido = new JTextField();
        txtEdad = new JTextField();
        cmbSexo = new JComboBox<>(new String[]{"Masculino", "Femenino", "Otro"});

        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(txtNombre);
        formPanel.add(new JLabel("Apellido:"));
        formPanel.add(txtApellido);
        formPanel.add(new JLabel("Edad:"));
        formPanel.add(txtEdad);
        formPanel.add(new JLabel("Género:"));
        formPanel.add(cmbSexo);

        // Botones
        btnNuevo = new JButton("Nuevo");
        btnAgregar = new JButton("Guardar");
        btnEliminar = new JButton("Eliminar");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(btnNuevo);
        buttonPanel.add(btnAgregar);
        buttonPanel.add(btnEliminar);

        formPanel.add(new JLabel()); // espacio vacío
        formPanel.add(buttonPanel);

        add(formPanel, BorderLayout.NORTH);

        // --- Tabla ---
        modelo = new DefaultTableModel(new String[]{"ID", "Nombre", "Apellido", "Edad", "Género"}, 0);
        tblParticipantes = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tblParticipantes);
        add(scrollPane, BorderLayout.CENTER);

        // --- Eventos ---
        btnNuevo.addActionListener(e -> limpiarCampos());
        btnAgregar.addActionListener(e -> {
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Nuevo Participante", true);
        dialog.getContentPane().add(formPanel);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
        listarParticipantes(); // Actualizar tabla después del registro
    });

        btnEliminar.addActionListener(e -> eliminarParticipante());

        tblParticipantes.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                cargarDesdeTabla();
            }
        });

        listarParticipantes();
    }

    private void listarParticipantes() {
        modelo.setRowCount(0);
        List<Participante> lista = dao.listar();
        for (Participante p : lista) {
            modelo.addRow(new Object[]{
                p.getIdParticipante(), p.getNombre(), p.getApellido(), p.getEdad(), p.getSexo()
            });
        }
    }

    private void cargarDesdeTabla() {
        int fila = tblParticipantes.getSelectedRow();
        if (fila >= 0) {
            int id = (int) tblParticipantes.getValueAt(fila, 0);
            participanteSeleccionado = dao.obtenerPorId(id);
            if (participanteSeleccionado != null) {
                txtNombre.setText(participanteSeleccionado.getNombre());
                txtApellido.setText(participanteSeleccionado.getApellido());
                txtEdad.setText(String.valueOf(participanteSeleccionado.getEdad()));
                cmbSexo.setSelectedItem(participanteSeleccionado.getSexo());
            }
        }
    }

    private void eliminarParticipante() {
        if (participanteSeleccionado != null) {
            int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar participante?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (dao.eliminar(participanteSeleccionado.getIdParticipante())) {
                    JOptionPane.showMessageDialog(this, "Participante eliminado");
                    listarParticipantes();
                    limpiarCampos();
                }
                participanteSeleccionado = null;
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un participante");
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtEdad.setText("");
        cmbSexo.setSelectedIndex(0);
        participanteSeleccionado = null;
        tblParticipantes.clearSelection();
    }
}

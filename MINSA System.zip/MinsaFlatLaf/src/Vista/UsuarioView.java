/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */


import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Vista principal para la gestión de usuarios del sistema
 * Incluye funcionalidades de CRUD con interfaz moderna
 */
public class UsuarioView extends JPanel {
    
    // Componentes principales
    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;
    private TableRowSorter<DefaultTableModel> sorter;
    private JTextField campoFiltro;
    private JLabel labelContador;
    
    // Paleta de colores moderna
    private static final Color PRIMARY_COLOR = new Color(37, 99, 235);     // Azul profesional
    private static final Color SECONDARY_COLOR = new Color(248, 250, 252);  // Fondo suave
    private static final Color SUCCESS_COLOR = new Color(34, 197, 94);      // Verde éxito
    private static final Color WARNING_COLOR = new Color(251, 146, 60);     // Naranja advertencia
    private static final Color DANGER_COLOR = new Color(239, 68, 68);       // Rojo peligro
    private static final Color ACCENT_COLOR = new Color(99, 102, 241);      // Índigo acento
    private static final Color TEXT_PRIMARY = new Color(15, 23, 42);        // Texto principal
    private static final Color TEXT_SECONDARY = new Color(100, 116, 139);   // Texto secundario
    
    // Fuentes
    private static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 24);
    private static final Font SUBTITLE_FONT = new Font("Segoe UI", Font.PLAIN, 16);
    private static final Font BUTTON_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font TABLE_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font TABLE_HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public UsuarioView() {
        setBackground(SECONDARY_COLOR);
        setLayout(new BorderLayout(0, 0));
        initComponents();
        configurarEventos();
    }

    private void initComponents() {
        // Panel principal con padding
        JPanel mainPanel = new JPanel(new BorderLayout(0, 15));
        mainPanel.setBackground(SECONDARY_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header con título y estadísticas
        mainPanel.add(crearPanelHeader(), BorderLayout.NORTH);
        
        // Panel central con búsqueda y tabla
        mainPanel.add(crearPanelCentral(), BorderLayout.CENTER);
        
        // Panel de acciones
        mainPanel.add(crearPanelAcciones(), BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
    }

    private JPanel crearPanelHeader() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            BorderFactory.createEmptyBorder(25, 30, 25, 30)
        ));
        
        // Título principal
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("👥 Gestión de Usuarios");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(TEXT_PRIMARY);
        titlePanel.add(titleLabel, BorderLayout.WEST);
        
        // Panel de estadísticas
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        statsPanel.setBackground(Color.WHITE);
        
        labelContador = new JLabel("Total: 0 usuarios");
        labelContador.setFont(SUBTITLE_FONT);
        labelContador.setForeground(TEXT_SECONDARY);
        statsPanel.add(labelContador);
        
        titlePanel.add(statsPanel, BorderLayout.EAST);
        headerPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Subtítulo
        JLabel subtitleLabel = new JLabel("Administre los usuarios del sistema de manera eficiente");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        subtitleLabel.setForeground(TEXT_SECONDARY);
        subtitleLabel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        headerPanel.add(subtitleLabel, BorderLayout.CENTER);
        
        return headerPanel;
    }

    private JPanel crearPanelCentral() {
        JPanel centralPanel = new JPanel(new BorderLayout(0, 15));
        centralPanel.setBackground(SECONDARY_COLOR);
        
        // Panel de búsqueda
        centralPanel.add(crearPanelBusqueda(), BorderLayout.NORTH);
        
        // Panel de tabla
        centralPanel.add(crearPanelTabla(), BorderLayout.CENTER);
        
        return centralPanel;
    }

    private JPanel crearPanelBusqueda() {
        JPanel searchPanel = new JPanel(new BorderLayout());
        searchPanel.setBackground(Color.WHITE);
        searchPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        
        JLabel searchLabel = new JLabel("🔍 Buscar usuario:");
        searchLabel.setFont(BUTTON_FONT);
        searchLabel.setForeground(TEXT_PRIMARY);
        searchLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        
        campoFiltro = new JTextField();
        campoFiltro.setFont(TABLE_FONT);
        campoFiltro.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(203, 213, 225), 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        campoFiltro.setPreferredSize(new Dimension(300, 35));
        
        JPanel searchInputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        searchInputPanel.setBackground(Color.WHITE);
        searchInputPanel.add(searchLabel);
        searchInputPanel.add(campoFiltro);
        
        searchPanel.add(searchInputPanel, BorderLayout.WEST);
        
        return searchPanel;
    }

    private JPanel crearPanelTabla() {
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createLineBorder(new Color(226, 232, 240), 1));
        
        // Configurar modelo de tabla
        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        String[] columnas = {"ID", "Participante", "Rol", "Usuario", "Estado", "Acciones"};
        for (String columna : columnas) {
            modeloTabla.addColumn(columna);
        }

        tablaUsuarios = new JTable(modeloTabla);
        configurarTabla();
        
        // Configurar sorter para filtrado
        sorter = new TableRowSorter<>(modeloTabla);
        tablaUsuarios.setRowSorter(sorter);
        
        JScrollPane scrollPane = new JScrollPane(tablaUsuarios);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        return tablePanel;
    }

    private void configurarTabla() {
        tablaUsuarios.setRowHeight(45);
        tablaUsuarios.setFont(TABLE_FONT);
        tablaUsuarios.setSelectionBackground(new Color(239, 246, 255));
        tablaUsuarios.setSelectionForeground(TEXT_PRIMARY);
        tablaUsuarios.setShowGrid(false);
        tablaUsuarios.setIntercellSpacing(new Dimension(0, 1));
        tablaUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Configurar header
        tablaUsuarios.getTableHeader().setFont(TABLE_HEADER_FONT);
        tablaUsuarios.getTableHeader().setBackground(new Color(248, 250, 252));
        tablaUsuarios.getTableHeader().setForeground(TEXT_PRIMARY);
        tablaUsuarios.getTableHeader().setReorderingAllowed(false);
        tablaUsuarios.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(226, 232, 240)));
        
        // Configurar anchos de columna
        tablaUsuarios.getColumnModel().getColumn(0).setPreferredWidth(60);  // ID
        tablaUsuarios.getColumnModel().getColumn(1).setPreferredWidth(200); // Participante
        tablaUsuarios.getColumnModel().getColumn(2).setPreferredWidth(150); // Rol
        tablaUsuarios.getColumnModel().getColumn(3).setPreferredWidth(120); // Usuario
        tablaUsuarios.getColumnModel().getColumn(4).setPreferredWidth(100); // Estado
        tablaUsuarios.getColumnModel().getColumn(5).setPreferredWidth(120); // Acciones
        
        // Renderer personalizado para la columna de estado
        tablaUsuarios.getColumnModel().getColumn(4).setCellRenderer(new EstadoCellRenderer());
        
        // Renderer personalizado para la columna de acciones
        tablaUsuarios.getColumnModel().getColumn(5).setCellRenderer(new AccionesCellRenderer());
    }

    private JPanel crearPanelAcciones() {
        JPanel accionesPanel = new JPanel(new BorderLayout());
        accionesPanel.setBackground(Color.WHITE);
        accionesPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        ));
        
        // Botones principales
        JPanel botonesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        botonesPanel.setBackground(Color.WHITE);
        
        JButton btnAgregar = crearBotonModerno("➕ Nuevo Usuario", PRIMARY_COLOR, "Crear un nuevo usuario");
        btnAgregar.addActionListener(this::abrirFormularioAgregar);
        
        JButton btnRefrescar = crearBotonModerno("🔄 Actualizar", ACCENT_COLOR, "Actualizar la lista");
        btnRefrescar.addActionListener(this::refrescarTabla);
        
        JButton btnExportar = crearBotonModerno("📊 Exportar", SUCCESS_COLOR, "Exportar datos");
        btnExportar.addActionListener(this::exportarDatos);
        
        botonesPanel.add(btnAgregar);
        botonesPanel.add(btnRefrescar);
        botonesPanel.add(btnExportar);
        
        accionesPanel.add(botonesPanel, BorderLayout.WEST);
        
        return accionesPanel;
    }

    private JButton crearBotonModerno(String texto, Color colorFondo, String tooltip) {
        JButton btn = new JButton(texto);
        btn.setFocusPainted(false);
        btn.setBackground(colorFondo);
        btn.setForeground(Color.WHITE);
        btn.setFont(BUTTON_FONT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setToolTipText(tooltip);
        
        // Efectos hover mejorados
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(colorFondo.darker());
                btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(colorFondo.darker(), 1),
                    BorderFactory.createEmptyBorder(9, 19, 9, 19)
                ));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(colorFondo);
                btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
            }
        });
        
        return btn;
    }

    private void configurarEventos() {
        // Filtrado en tiempo real
        campoFiltro.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filtrarTabla(); }
            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filtrarTabla(); }
            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filtrarTabla(); }
        });
        
        // Doble clic para editar
        tablaUsuarios.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int fila = tablaUsuarios.getSelectedRow();
                    if (fila >= 0) {
                        editarUsuario(fila);
                    }
                }
            }
        });
    }

    private void filtrarTabla() {
        String texto = campoFiltro.getText().toLowerCase().trim();
        if (texto.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
        }
        actualizarContador();
    }

    private void actualizarContador() {
        int total = tablaUsuarios.getRowCount();
        labelContador.setText(String.format("Total: %d usuario%s", total, total != 1 ? "s" : ""));
    }

    // Métodos de acción mejorados
    private void abrirFormularioAgregar(ActionEvent evt) {
        SwingUtilities.invokeLater(() -> {
            try {
                new UsuarioForm(this, true).setVisible(true);
            } catch (Exception e) {
                mostrarMensajeError("Error al abrir el formulario: " + e.getMessage());
            }
        });
    }

    private void editarUsuario(int fila) {
        try {
            int filaModelo = tablaUsuarios.convertRowIndexToModel(fila);
            int id = (int) modeloTabla.getValueAt(filaModelo, 0);
            
            UsuarioForm form = new UsuarioForm(this, true);
            form.cargarDatos(
                id,
                (String) modeloTabla.getValueAt(filaModelo, 1),
                (String) modeloTabla.getValueAt(filaModelo, 2),
                (String) modeloTabla.getValueAt(filaModelo, 3),
                (String) modeloTabla.getValueAt(filaModelo, 4)
            );
            form.setVisible(true);
        } catch (Exception e) {
            mostrarMensajeError("Error al editar usuario: " + e.getMessage());
        }
    }

    private void eliminarUsuario(int fila) {
        try {
            int filaModelo = tablaUsuarios.convertRowIndexToModel(fila);
            String nombre = (String) modeloTabla.getValueAt(filaModelo, 1);
            
            int confirmacion = mostrarDialogoConfirmacion(
                "Confirmar eliminación",
                String.format("¿Está seguro de eliminar al usuario '%s'?", nombre),
                "Esta acción no se puede deshacer."
            );
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                modeloTabla.removeRow(filaModelo);
                mostrarMensajeExito("Usuario eliminado correctamente");
                actualizarContador();
            }
        } catch (Exception e) {
            mostrarMensajeError("Error al eliminar usuario: " + e.getMessage());
        }
    }

    private void refrescarTabla(ActionEvent evt) {
        // Simular carga de datos
        SwingUtilities.invokeLater(() -> {
            // Aquí iría la lógica para recargar desde la base de datos
            actualizarContador();
            mostrarMensajeExito("Datos actualizados correctamente");
        });
    }

    private void exportarDatos(ActionEvent evt) {
        // Implementar exportación (CSV, Excel, etc.)
        mostrarMensajeInfo("Funcionalidad de exportación en desarrollo");
    }

    // Métodos auxiliares para datos de ejemplo
    private void cargarDatosEjemplo() {
        List<Object[]> usuarios = new ArrayList<>();
        usuarios.add(new Object[]{1, "Juan Pérez", "Administrador", "jperez", "Activo", ""});
        usuarios.add(new Object[]{2, "María Gómez", "Jefa de Obstetricia", "mgomez", "Activo", ""});
        usuarios.add(new Object[]{3, "Riccy Suyon", "Obstetra", "rsuyon", "Inactivo", ""});
        usuarios.add(new Object[]{4, "Ana García", "Enfermera", "agarcia", "Activo", ""});
        usuarios.add(new Object[]{5, "Carlos Ruiz", "Médico", "cruiz", "Activo", ""});
        
        for (Object[] usuario : usuarios) {
            modeloTabla.addRow(usuario);
        }
        actualizarContador();
    }

    // Métodos de mensajería mejorados
    private void mostrarMensajeError(String mensaje) {
        JOptionPane.showMessageDialog(
            this,
            mensaje,
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }

    private void mostrarMensajeExito(String mensaje) {
        JOptionPane.showMessageDialog(
            this,
            mensaje,
            "Éxito",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void mostrarMensajeInfo(String mensaje) {
        JOptionPane.showMessageDialog(
            this,
            mensaje,
            "Información",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    private int mostrarDialogoConfirmacion(String titulo, String mensaje, String detalle) {
        String mensajeCompleto = String.format("<html><b>%s</b><br><br>%s</html>", mensaje, detalle);
        return JOptionPane.showConfirmDialog(
            this,
            mensajeCompleto,
            titulo,
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
    }

    // Métodos públicos para integración
    public void agregarUsuario(Object[] datos) {
        modeloTabla.addRow(datos);
        actualizarContador();
    }

    public void actualizarUsuario(int fila, Object[] datos) {
        for (int i = 0; i < datos.length; i++) {
            modeloTabla.setValueAt(datos[i], fila, i);
        }
    }

    // Clases internas para renderers personalizados
    private class EstadoCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (value != null) {
                String estado = value.toString();
                if ("Activo".equals(estado)) {
                    setForeground(SUCCESS_COLOR);
                    setText("● Activo");
                } else if ("Inactivo".equals(estado)) {
                    setForeground(DANGER_COLOR);
                    setText("● Inactivo");
                }
                setFont(new Font("Segoe UI", Font.BOLD, 12));
            }
            
            if (isSelected) {
                setBackground(table.getSelectionBackground());
            } else {
                setBackground(Color.WHITE);
            }
            
            return c;
        }
    }

    private class AccionesCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 0));
            panel.setOpaque(true);
            
            if (isSelected) {
                panel.setBackground(table.getSelectionBackground());
            } else {
                panel.setBackground(Color.WHITE);
            }
            
            JButton btnEditar = new JButton("✏️");
            btnEditar.setPreferredSize(new Dimension(30, 25));
            btnEditar.setBackground(WARNING_COLOR);
            btnEditar.setForeground(Color.WHITE);
            btnEditar.setBorder(BorderFactory.createEmptyBorder());
            btnEditar.setFocusPainted(false);
            btnEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btnEditar.addActionListener(e -> editarUsuario(row));
            
            JButton btnEliminar = new JButton("🗑️");
            btnEliminar.setPreferredSize(new Dimension(30, 25));
            btnEliminar.setBackground(DANGER_COLOR);
            btnEliminar.setForeground(Color.WHITE);
            btnEliminar.setBorder(BorderFactory.createEmptyBorder());
            btnEliminar.setFocusPainted(false);
            btnEliminar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btnEliminar.addActionListener(e -> eliminarUsuario(row));
            
            panel.add(btnEditar);
            panel.add(btnEliminar);
            
            return panel;
        }
    }

    // Método main para pruebas
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
            UIManager.put("Button.arc", 8);
            UIManager.put("Component.arc", 8);
            UIManager.put("TextComponent.arc", 5);
        } catch (Exception ex) {
            System.err.println("Error al configurar FlatLaf: " + ex.getMessage());
        }

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Sistema de Gestión de Usuarios");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1100, 750);
            frame.setLocationRelativeTo(null);
            
            UsuarioView view = new UsuarioView();
            view.cargarDatosEjemplo();
            
            frame.setContentPane(view);
            frame.setVisible(true);
        });
    }
}
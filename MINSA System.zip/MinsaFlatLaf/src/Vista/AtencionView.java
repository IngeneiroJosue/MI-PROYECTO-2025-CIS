/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.util.UIScale;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.table.DefaultTableCellRenderer;

public class AtencionView extends JPanel {
    private JTable tablaAtenciones;
    private DefaultTableModel modeloTabla;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    public AtencionView() {
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(UIManager.getColor("Panel.background"));
        initComponents();
        applyModernStyles();
    }

    private void initComponents() {
        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Participante");
        modeloTabla.addColumn("Fecha");
        modeloTabla.addColumn("Observación");

        tablaAtenciones = new JTable(modeloTabla);
        tablaAtenciones.setRowHeight(UIScale.scale(40));
        tablaAtenciones.setShowHorizontalLines(true);
        tablaAtenciones.setShowVerticalLines(false);
        tablaAtenciones.setIntercellSpacing(new Dimension(0, 5));
        tablaAtenciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JTableHeader header = tablaAtenciones.getTableHeader();
        header.setReorderingAllowed(false);
        header.setFont(header.getFont().deriveFont(Font.BOLD));

        JScrollPane scrollPane = new JScrollPane(tablaAtenciones);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.putClientProperty(FlatClientProperties.STYLE, "border: 5,5,5,5,shade(@background,10%),,5");

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBotones.setBorder(new EmptyBorder(15, 0, 0, 0));
        panelBotones.setOpaque(false);

        JButton btnAgregar = createModernButton("Agregar", new Color(46, 204, 113));
        btnAgregar.addActionListener(this::abrirFormularioAgregar); 

        JButton btnEditar = createModernButton("Editar", new Color(52, 152, 219));
        /*btnEditar.addActionListener(this::abrirFormularioEditar);*/

        JButton btnEliminar = createModernButton("Eliminar", new Color(231, 76, 60));
        btnEliminar.addActionListener(this::eliminarAtencion);

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);

        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titlePanel.setOpaque(false);
        titlePanel.setBorder(new EmptyBorder(0, 0, 15, 0));

        JLabel titleLabel = new JLabel("Gestión de Atenciones");
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 18f));
        titleLabel.setForeground(new Color(52, 73, 94));
        titlePanel.add(titleLabel);

        add(titlePanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        cargarDatosEjemplo();
    }

    private void applyModernStyles() {
        tablaAtenciones.setDefaultRenderer(Object.class, new ModernTableCellRenderer());
    }

    private JButton createModernButton(String text, Color bgColor) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(bgColor.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(bgColor.brighter());
                } else {
                    g2.setColor(bgColor);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(button.getFont().deriveFont(Font.BOLD));
        button.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setFocusPainted(false);
        return button;
    }

    private void cargarDatosEjemplo() {
        Object[] fila1 = {1, "Juan Pérez", dateFormat.format(new Date()), "Consulta de rutina"};
        Object[] fila2 = {2, "María Gómez", dateFormat.format(new Date()), "Control prenatal"};
        modeloTabla.addRow(fila1);
        modeloTabla.addRow(fila2);
    }

     private void abrirFormularioAgregar(ActionEvent evt) {
        FormularioAtencion form = new FormularioAtencion();
       form.setVisible(true);
        
    } 
     
    

    private void eliminarAtencion(ActionEvent evt) {
        int filaSeleccionada = tablaAtenciones.getSelectedRow()  ;
        if (filaSeleccionada == -1) {
            showErrorDialog("Seleccione una atención para eliminar");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro de eliminar esta atención?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            modeloTabla.removeRow(filaSeleccionada);
            JOptionPane.showMessageDialog(
                this,
                "Atención eliminada correctamente",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void agregarAtencion(Object[] datos) {
        modeloTabla.addRow(datos);
        JOptionPane.showMessageDialog(this, "Atención agregada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    public void actualizarAtencion(int fila, Object[] datos) {
        for (int i = 0; i < datos.length; i++) {
            modeloTabla.setValueAt(datos[i], fila, i);
        }
        JOptionPane.showMessageDialog(this, "Atención actualizada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    public DefaultTableModel getModeloTabla() {
        return modeloTabla;
    }

    public JTable getTablaAtenciones() {
        return tablaAtenciones;
    }

    private static class ModernTableCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {

            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            setBorder(new EmptyBorder(0, 10, 0, 10));

            if (isSelected) {
                setBackground(new Color(52, 152, 219));
                setForeground(Color.WHITE);
            } else {
                if (row % 2 == 0) {
                    setBackground(Color.WHITE);
                } else {
                    setBackground(new Color(245, 245, 245));
                }
                setForeground(Color.BLACK);
            }

            return this;
        }
    }
}
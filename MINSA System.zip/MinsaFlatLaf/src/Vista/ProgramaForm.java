/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */

import Modelo.Programa;
import javax.swing.*;
import java.awt.*;
import javax.swing.text.NumberFormatter;
import java.awt.event.ActionEvent;
import java.text.NumberFormat;

public class ProgramaForm extends JPanel {
    private final JTextField txtNombre;
    private final JFormattedTextField txtMeta;
    private final JFormattedTextField txtAnio;
    private final Programa programa;

    public interface FormListener {
        void onGuardar(Programa programa, boolean edicion);
        void onCancelar(); // <- nuevo método
    }

    public ProgramaForm(Programa programaInicial, FormListener listener) {
        this.programa = programaInicial != null ? programaInicial : new Programa();

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        setBackground(UIManager.getColor("Panel.background"));

        JLabel lblTitulo = new JLabel(programaInicial == null ? "➕ Nuevo Programa" : "✏️ Editar Programa", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        // Formato para números enteros
        NumberFormat formatoEntero = NumberFormat.getIntegerInstance();
        formatoEntero.setGroupingUsed(false);
        NumberFormatter formatter = new NumberFormatter(formatoEntero);
        formatter.setAllowsInvalid(false);
        formatter.setMinimum(0);

        txtNombre = new JTextField();
        txtMeta = new JFormattedTextField(formatter);
        txtAnio = new JFormattedTextField(formatter);

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 12, 12));
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

        formPanel.add(new JLabel("📌 Nombre del Programa:"));
        formPanel.add(txtNombre);

        formPanel.add(new JLabel("🎯 Meta:"));
        formPanel.add(txtMeta);

        formPanel.add(new JLabel("📅 Año:"));
        formPanel.add(txtAnio);

        if (programaInicial != null) {
            txtNombre.setText(programaInicial.getNombrePrograma());
            txtMeta.setValue(programaInicial.getMeta());
            txtAnio.setValue(programaInicial.getAño());
        }

        JButton btnLimpiar = new JButton("🧹 Limpiar");
        JButton btnCancelar = new JButton("❌ Cancelar");
        JButton btnGuardar = new JButton("💾 Guardar");

        Font font = new Font("Segoe UI", Font.PLAIN, 14);
        btnLimpiar.setFont(font);
        btnCancelar.setFont(font);
        btnGuardar.setFont(font);

        btnLimpiar.setBackground(new Color(240, 240, 240));
        btnCancelar.setBackground(new Color(220, 53, 69));
        btnGuardar.setBackground(new Color(25, 135, 84));

        btnLimpiar.setForeground(Color.BLACK);
        btnCancelar.setForeground(Color.WHITE);
        btnGuardar.setForeground(Color.WHITE);

        btnLimpiar.setFocusPainted(false);
        btnCancelar.setFocusPainted(false);
        btnGuardar.setFocusPainted(false);

        btnLimpiar.addActionListener(e -> {
            txtNombre.setText("");
            txtMeta.setValue(null);
            txtAnio.setValue(null);
        });

        btnCancelar.addActionListener(e -> {
            listener.onCancelar(); // Volver a ProgramaView
        });

        btnGuardar.addActionListener((ActionEvent e) -> {
            try {
                programa.setNombrePrograma(txtNombre.getText().trim());
                programa.setMeta(((Number) txtMeta.getValue()).intValue());
                programa.setAño(((Number) txtAnio.getValue()).intValue());
                listener.onGuardar(programa, programaInicial != null);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Completa correctamente todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        panelBotones.setOpaque(false);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        add(lblTitulo, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }
}

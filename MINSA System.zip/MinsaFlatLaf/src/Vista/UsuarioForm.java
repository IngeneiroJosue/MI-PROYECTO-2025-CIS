/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Dao.UsuarioDAO;
import Modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class UsuarioForm extends JPanel {
    private JComboBox<String> cbParticipante, cbRol, cbEstado;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnGuardar, btnCancelar;
    private UsuarioView parentView;
    private boolean isEdit;
    private int idEdit;

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    public UsuarioForm(UsuarioView parent) {
        this.parentView = parent;
        this.isEdit = false;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Campos del formulario
        panel.add(new JLabel("Participante:"));
        cbParticipante = new JComboBox<>(new String[]{"Juan Pérez", "María Gómez", "Carlos López"});
        panel.add(cbParticipante);

        panel.add(new JLabel("Rol:"));
        cbRol = new JComboBox<>(new String[]{"Administrador", "Médico", "Enfermero", "Usuario"});
        panel.add(cbRol);

        panel.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField();
        panel.add(txtUsuario);

        panel.add(new JLabel("Contraseña:"));
        txtContrasena = new JPasswordField();
        panel.add(txtContrasena);

        panel.add(new JLabel("Estado:"));
        cbEstado = new JComboBox<>(new String[]{"Activo", "Inactivo", "Bloqueado"});
        panel.add(cbEstado);

        // Botones
        btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(this::guardarUsuario);
        panel.add(btnGuardar);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> parentView.mostrarPanelPrincipal());
        panel.add(btnCancelar);

        add(panel, BorderLayout.CENTER);
    }

    public void cargarDatosParaEditar(int id, String participante, String rol, String usuario, String estado) {
        this.isEdit = true;
        this.idEdit = id;

        cbParticipante.setSelectedItem(participante);
        cbRol.setSelectedItem(rol);
        txtUsuario.setText(usuario);
        cbEstado.setSelectedItem(estado);
    }

    public void setEdit(boolean edit) {
        this.isEdit = edit;
    }

    private void guardarUsuario(ActionEvent evt) {
        String usuario = txtUsuario.getText();
        String contrasena = new String(txtContrasena.getPassword());

        if (usuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe completar los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Usuario u = new Usuario();
        u.setUsuario(usuario);
        u.setClave(contrasena);
        u.setEstado(cbEstado.getSelectedIndex());
        u.setIdParticipante(cbParticipante.getSelectedIndex() + 1);
        u.setIdRol(cbRol.getSelectedIndex() + 1);

        try {
            if (isEdit) {
                u.setIdUsuario(idEdit);
                usuarioDAO.actualizar(u);
                JOptionPane.showMessageDialog(this, "Usuario actualizado correctamente");
            } else {
                usuarioDAO.insertar(u);
                JOptionPane.showMessageDialog(this, "Usuario registrado correctamente");
            }
            parentView.refrescarTabla(null);
            parentView.mostrarPanelPrincipal();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

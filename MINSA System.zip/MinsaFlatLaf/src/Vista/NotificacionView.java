/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class NotificacionView extends JPanel {
    private JButton bellButton;
    private JLabel badgeLabel;
    private int notificationCount = 0;
    private final JPopupMenu notificationMenu;
    private final List<String> notifications;

    public NotificacionView() {
        setLayout(null);
        setOpaque(false);

        notifications = new ArrayList<>();
        notificationMenu = new JPopupMenu();
        notificationMenu.setBorder(new LineBorder(Color.GRAY));

        bellButton = new JButton("🔔");
        bellButton.setFocusPainted(false);
        bellButton.setBorderPainted(false);
        bellButton.setContentAreaFilled(false);
        bellButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        bellButton.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        bellButton.setBounds(0, 0, 50, 50);

        bellButton.addActionListener(e -> {
            if (notificationCount > 0) {
                mostrarPopup(bellButton);
            } else {
                JOptionPane.showMessageDialog(this, "No tienes nuevas notificaciones.");
            }
        });

        badgeLabel = new JLabel("0", SwingConstants.CENTER);
        badgeLabel.setForeground(Color.WHITE);
        badgeLabel.setBackground(Color.RED);
        badgeLabel.setOpaque(true);
        badgeLabel.setFont(new Font("Arial", Font.BOLD, 11));
        badgeLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        badgeLabel.setBounds(30, 2, 16, 16);
        badgeLabel.setVisible(false);

        add(bellButton);
        add(badgeLabel);
        setPreferredSize(new Dimension(50, 50));
    }

    private void mostrarPopup(Component parent) {
        notificationMenu.removeAll();
        for (String noti : notifications) {
            JMenuItem item = new JMenuItem(noti);
            item.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            notificationMenu.add(item);
        }
        notificationMenu.show(parent, 0, parent.getHeight());
    }

    public void setNotificationCount(int count) {
        this.notificationCount = count;
        badgeLabel.setText(String.valueOf(count));
        badgeLabel.setVisible(count > 0);
    }

    public void addNotification(String text) {
        notifications.add(text);
        setNotificationCount(notifications.size());
    }

    public void clearNotifications() {
        notifications.clear();
        setNotificationCount(0);
    }

}

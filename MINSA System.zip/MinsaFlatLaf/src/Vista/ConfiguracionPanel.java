/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;

import javax.swing.*;
import java.awt.*;

public class ConfiguracionPanel extends JPanel {

    private final Color fondoClaro = new Color(245, 249, 252);
    private final Color fondoOscuro = new Color(45, 45, 45);

    public ConfiguracionPanel() {
        setLayout(new BorderLayout());
        setBackground(fondoClaro);
        initComponents();
    }

    private void initComponents() {
        JPanel panelContenido = new JPanel();
        panelContenido.setLayout(new BoxLayout(panelContenido, BoxLayout.Y_AXIS));
        panelContenido.setBackground(getBackground());
        panelContenido.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel lblTitulo = new JLabel("Configuración de Tema");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        panelContenido.add(lblTitulo);
        panelContenido.add(Box.createRigidArea(new Dimension(0, 30)));

        // Selector de tema
        JLabel lblTema = new JLabel("Seleccionar tema:");
        lblTema.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblTema.setAlignmentX(Component.LEFT_ALIGNMENT);

        JRadioButton radioClaro = new JRadioButton("Claro");
        JRadioButton radioOscuro = new JRadioButton("Oscuro");

        radioClaro.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        radioOscuro.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        ButtonGroup group = new ButtonGroup();
        group.add(radioClaro);
        group.add(radioOscuro);

        radioClaro.setSelected(UIManager.getLookAndFeel().getClass().getName().contains("Light"));

        radioClaro.setAlignmentX(Component.LEFT_ALIGNMENT);
        radioOscuro.setAlignmentX(Component.LEFT_ALIGNMENT);

        panelContenido.add(lblTema);
        panelContenido.add(radioClaro);
        panelContenido.add(radioOscuro);

        panelContenido.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton btnAplicar = new JButton("Aplicar Tema");
        btnAplicar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAplicar.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnAplicar.setBackground(new Color(0, 102, 204));
        btnAplicar.setForeground(Color.WHITE);
        btnAplicar.setFocusPainted(false);
        btnAplicar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btnAplicar.addActionListener(e -> {
            try {
                if (radioClaro.isSelected()) {
                    UIManager.setLookAndFeel(new FlatLightLaf());
                    SwingUtilities.updateComponentTreeUI(SwingUtilities.getWindowAncestor(this));
                } else if (radioOscuro.isSelected()) {
                    UIManager.setLookAndFeel(new FlatDarkLaf());
                    SwingUtilities.updateComponentTreeUI(SwingUtilities.getWindowAncestor(this));
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "No se pudo aplicar el tema.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panelContenido.add(btnAplicar);

        add(panelContenido, BorderLayout.NORTH);
    }
}


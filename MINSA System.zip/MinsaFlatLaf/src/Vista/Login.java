/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */
import Dao.UsuarioDAO;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.extras.FlatSVGIcon;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnLogin;
    private JCheckBox chkCaptcha;
    private JLabel lblIntentos, lblToggle, lblLogo;
    private JLabel lblIconUser, lblIconLock, lblTemporizador;
    private JButton btnTema;

    private boolean esTemaOscuro = false;
    private boolean mostrarContrasena = false;
    private int intentosFallidos = 0;
    private int segundosBloqueo = 10;
    private int idUsuarioGlobal;
    private Timer timer;

    private final int MAX_INTENTOS = 3;
    private final ImageIcon iconoMostrar = new ImageIcon("src\\Icon\\ojo.png");
    private final ImageIcon iconoOcultar = new ImageIcon("src\\Icon\\invisible.png");
    

    public Login() {
        setTitle("Inicio de Sesión - MINSA");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(420, 470);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        UIManager.put("TextComponent.arc", 15);
        UIManager.put("Component.arc", 20);
        UIManager.put("Button.arc", 15);
        UIManager.put("Component.focusWidth", 1);

        FlatLightLaf.setup();

        iniciarComponentes();
    }

    private void iniciarComponentes() {
        lblLogo = new JLabel();
        lblLogo.setBounds(160, 20, 100, 100);
        SetImagenLabel(lblLogo, "src\\Icon\\mujer.png");
        add(lblLogo);

        JLabel lblTitulo = new JLabel("MINSA");
        lblTitulo.setBounds(90, 120, 250, 30);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        add(lblTitulo);

        // Ícono usuario
        lblIconUser = new JLabel();
        lblIconUser.setBounds(65, 170, 30, 30);
        SetImagenLabel(lblIconUser, "src\\Icon\\usuario.png");
        add(lblIconUser);

        txtUsuario = new JTextField("");
        txtUsuario.setBounds(100, 170, 200, 30);
        txtUsuario.setToolTipText("Ingrese su usuario");
        add(txtUsuario);

        // Ícono contraseña
        lblIconLock = new JLabel();
        lblIconLock.setBounds(65, 210, 30, 30);
        SetImagenLabel(lblIconLock, "src\\Icon\\pass.png");
        add(lblIconLock);

        txtContrasena = new JPasswordField("");
        txtContrasena.setBounds(100, 210, 200, 30);
        txtContrasena.setEchoChar('•');
        txtContrasena.setToolTipText("Ingrese su contraseña");
        add(txtContrasena);

        lblToggle = new JLabel(iconoMostrarEscalado);
        lblToggle.setBounds(305, 210, ancho, alto); 
        lblToggle.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(lblToggle);

        chkCaptcha = new JCheckBox("No soy un robot");
        chkCaptcha.setBounds(100, 250, 200, 30);
        add(chkCaptcha);

        btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setBounds(100, 290, 200, 35);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogin.setFocusPainted(false);
        add(btnLogin);

        lblIntentos = new JLabel("Intentos restantes: 3");
        lblIntentos.setBounds(100, 330, 200, 20);
        lblIntentos.setForeground(Color.RED);
        lblIntentos.setHorizontalAlignment(SwingConstants.CENTER);
        add(lblIntentos);

        lblTemporizador = new JLabel("");
        lblTemporizador.setBounds(100, 350, 200, 20);
        lblTemporizador.setHorizontalAlignment(SwingConstants.CENTER);
        lblTemporizador.setForeground(new Color(0, 120, 250));
        add(lblTemporizador);

        

        // Acciones
       lblToggle.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            mostrarContrasena = !mostrarContrasena;
            txtContrasena.setEchoChar(mostrarContrasena ? (char) 0 : '•');
            lblToggle.setIcon(mostrarContrasena ? iconoOcultarEscalado : iconoMostrarEscalado);
         }
        });

        btnLogin.addActionListener(e -> validarCredenciales());

        txtUsuario.addActionListener(e -> txtContrasena.requestFocus());
        txtContrasena.addActionListener(e -> btnLogin.doClick());
    }

    private void validarCredenciales() {
        String usuario = txtUsuario.getText();
        String contrasena = String.valueOf(txtContrasena.getPassword());

        if (usuario.isEmpty() && usuario.isEmpty() && !chkCaptcha.isSelected()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese usuario, contraseña y marque la casilla.", "Campos Requeridos", JOptionPane.WARNING_MESSAGE);
        } else if (usuario.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese usuario.", "Usuario Requerido",JOptionPane.WARNING_MESSAGE);
        } else if (contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese contraseña.", "Contraseña Requerida",JOptionPane.WARNING_MESSAGE);
        } else if (!chkCaptcha.isSelected()) {
            JOptionPane.showMessageDialog(this, "Por favor, confirme que no es un robot.", "Captcha requerido", JOptionPane.WARNING_MESSAGE);
            
        } else {
           UsuarioDAO uDao = new UsuarioDAO();
        try {

            idUsuarioGlobal = uDao.validarCredenciales(usuario,contrasena);

            if(idUsuarioGlobal >= 0 ) {
            JOptionPane.showMessageDialog(this, "¡Bienvenido, " + usuario + "!", "Acceso concedido", JOptionPane.INFORMATION_MESSAGE);
            intentosFallidos = 0;
            new DashboardFrame(idUsuarioGlobal, "Administrador", 1).setVisible(true);
            this.dispose();
        } else {
            intentosFallidos++;
            int intentosRestantes = MAX_INTENTOS - intentosFallidos;
            lblIntentos.setText("Intentos restantes: " + intentosRestantes);
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas. Intente nuevamente.", "Error", JOptionPane.ERROR_MESSAGE);

            if (intentosFallidos >= MAX_INTENTOS) {
                bloquearLogin();
            }
        } 
    } catch (RuntimeException ex) {
        JOptionPane.showMessageDialog(this, "Error al iniciar sesion: " + ex.getMessage() );
    
    }
    }
    }

    private void bloquearLogin() {
        btnLogin.setEnabled(false);
        lblTemporizador.setText("Reintente en " + segundosBloqueo + " segundos...");
        segundosBloqueo = 90;

        timer = new Timer(1000, e -> {
            segundosBloqueo--;
            lblTemporizador.setText("Reintente en " + segundosBloqueo + " segundos...");
            if (segundosBloqueo <= 0) {
                timer.stop();
                btnLogin.setEnabled(true);
                intentosFallidos = 0;
                lblIntentos.setText("Intentos restantes: 3");
                lblTemporizador.setText("");
                segundosBloqueo = 90;
            }
        });
        timer.start();

        JOptionPane.showMessageDialog(this, "Demasiados intentos fallidos. Espere unos segundos.", "Bloqueado temporalmente", JOptionPane.WARNING_MESSAGE);
    }

    public void SetImagenLabel(JLabel label, String ruta) {
        ImageIcon image = new ImageIcon(ruta);
        Icon icon = new ImageIcon(image.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH));
        label.setIcon(icon);
    }
    
    // Tamaño del botón
    int ancho = 25;
    int alto = 25;

    // Escalamos el ícono de mostrar
    ImageIcon iconoMostrarEscalado = new ImageIcon(
        iconoMostrar.getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH)
    );

    // Escalamos el ícono de ocultar
    ImageIcon iconoOcultarEscalado = new ImageIcon(
        iconoOcultar.getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH)
    );

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}


package Vista;

import Dao.Conexion;
import Dao.ProgramaDAO;
import Dao.ProgramaDAOImpl;
import Modelo.Programa;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.util.List;

public class ProgramaView extends JPanel {
    private final DefaultTableModel modeloTabla;
    private final JTable tabla;
    private final ProgramaDAO programaDAO;
    private final CardLayout cardLayout;
    private final JPanel contenedor;
    private final JPanel panelLista;
    private final JPanel panelForm; // <-- Reutilizable

    public ProgramaView() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.establecerConexion();
        programaDAO = new ProgramaDAOImpl(conn);

        setLayout(new BorderLayout());

        cardLayout = new CardLayout();
        contenedor = new JPanel(cardLayout);

        // Panel principal (lista)
        panelLista = new JPanel(new BorderLayout());
        panelLista.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("Gestión de Programas", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Meta", "Año"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };

        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(30);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));

        JScrollPane scrollPane = new JScrollPane(tabla);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnAgregar = new JButton("➕ Agregar");
        JButton btnEditar = new JButton("✏️ Editar");
        JButton btnEliminar = new JButton("🗑️ Eliminar");

        btnAgregar.addActionListener(this::abrirFormularioAgregar);
        btnEditar.addActionListener(this::abrirFormularioEditar);
        btnEliminar.addActionListener(this::eliminarPrograma);

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);

        panelLista.add(lblTitulo, BorderLayout.NORTH);
        panelLista.add(scrollPane, BorderLayout.CENTER);
        panelLista.add(panelBotones, BorderLayout.SOUTH);

        // Panel para formulario
        panelForm = new JPanel(new BorderLayout());

        contenedor.add(panelLista, "LISTA");
        contenedor.add(panelForm, "FORM");

        add(contenedor, BorderLayout.CENTER);

        cargarDatos();
    }

    private void cargarDatos() {
        modeloTabla.setRowCount(0);
        List<Programa> lista = programaDAO.listarActivos();
        for (Programa p : lista) {
            modeloTabla.addRow(new Object[]{p.getIdPrograma(), p.getNombrePrograma(), p.getMeta(), p.getAño()});
        }
    }

    private void abrirFormularioAgregar(ActionEvent e) {
        ProgramaForm form = new ProgramaForm(null, new ProgramaForm.FormListener() {
            public void onGuardar(Programa programa, boolean edicion) {
                programaDAO.registrar(programa);
                cargarDatos();
                cardLayout.show(contenedor, "LISTA");
            }

            public void onCancelar() {
                cardLayout.show(contenedor, "LISTA");
            }
        });
        mostrarFormulario(form);
    }

    private void abrirFormularioEditar(ActionEvent e) {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un programa", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) modeloTabla.getValueAt(fila, 0);
        Programa p = programaDAO.obtenerPorId(id);

        ProgramaForm form = new ProgramaForm(p, new ProgramaForm.FormListener() {
            public void onGuardar(Programa programa, boolean edicion) {
                programaDAO.actualizar(programa);
                cargarDatos();
                cardLayout.show(contenedor, "LISTA");
            }

            public void onCancelar() {
                cardLayout.show(contenedor, "LISTA");
            }
        });

        mostrarFormulario(form);
    }

    private void eliminarPrograma(ActionEvent e) {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un programa", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) modeloTabla.getValueAt(fila, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "¿Seguro que desea eliminar?", "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            programaDAO.eliminar(id);
            cargarDatos();
        }
    }

    private void mostrarFormulario(ProgramaForm form) {
        panelForm.removeAll();
        panelForm.add(form, BorderLayout.CENTER);
        panelForm.revalidate();
        panelForm.repaint();
        cardLayout.show(contenedor, "FORM");
    }
}

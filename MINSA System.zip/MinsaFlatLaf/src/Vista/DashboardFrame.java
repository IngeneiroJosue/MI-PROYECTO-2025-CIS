package Vista;
import Dao.RolAccesoDAO;
import Dao.RolAccesoDAOImpl;
import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.fonts.roboto.FlatRobotoFont;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import com.formdev.flatlaf.util.UIScale;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class DashboardFrame extends JFrame {

    // Colores del tema
    private static final Color PRIMARY_COLOR = new Color(0, 102, 102);      // Verde azulado profesional
    private static final Color ACCENT_COLOR = new Color(0, 128, 128);      // Verde azulado más oscuro
    private static final Color SECONDARY_COLOR = new Color(245, 245, 245);
    private static final Color CARD_BG = Color.WHITE;
    private static final Color TEXT_PRIMARY = new Color(33, 33, 33);
    private static final Color TEXT_SECONDARY = new Color(117, 117, 117);

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(cardLayout);
    private JButton currentSelectedButton;
    private JLabel headerTitle;
    private JLabel breadcrumbLabel;
    private JLabel userRoleLabel;
    private int currentUserId;
    private String currentUserName;
    private int currentUserRoleId;
    private Map<String, List<String>> roleAccessMap = new HashMap<>();
    private Connection conexion;
    private RolAccesoDAO rolAccesoDAO;

    public DashboardFrame(int userId, String userName, int roleId) {
        this.currentUserId = userId;
        this.currentUserName = userName;
        this.currentUserRoleId = roleId;
        this.conexion = conexion;
        this.rolAccesoDAO = new RolAccesoDAOImpl();
        
        
        setupLookAndFeel();
        loadRoleAccess();
        initializeComponents();
        setupLayout();
        setDefaultView();
        
        System.setProperty("flatlaf.uiScale", "1.0");
    }

    private void setupLookAndFeel() {
        FlatRobotoFont.install();
        UIManager.put("defaultFont", new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 14));
        
        try {
            FlatMacLightLaf.setup();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        UIManager.put("Button.arc", 8);
        UIManager.put("Component.arc", 8);
        UIManager.put("TextComponent.arc", 6);
        UIManager.put("ScrollBar.width", 12);
        UIManager.put("ScrollBar.thumbArc", 6);
        UIManager.put("ScrollBar.thumbInsets", new Insets(2, 2, 2, 2));
    }

    private void loadRoleAccess() {
        roleAccessMap = rolAccesoDAO.obtenerAccesoPorRol(currentUserRoleId, conexion);
        String roleName = rolAccesoDAO.obtenerNombreRol(currentUserRoleId, conexion);
        
        if (roleName != null){
            userRoleLabel = new JLabel(roleName);
        }else{
            JOptionPane.showMessageDialog(this,
                    "Error al cargar los permisos de rol", 
                    "Error", JOptionPane.ERROR_MESSAGE);

        }
        
        
    }

    private void initializeComponents() {
        setTitle("Sistema de Gestión de Salud - MINSA");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(UIScale.scale(1200), UIScale.scale(750));
        setLocationRelativeTo(null);
        setResizable(true);
        setMinimumSize(new Dimension(1024, 640));
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        
        add(createSidebar(), BorderLayout.WEST);
        add(createMainContent(), BorderLayout.CENTER);
        
        setupViews();
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(getBackgroundColor());
        sidebar.setLayout(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(UIScale.scale(280), getHeight()));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, getSeparatorColor()));

        sidebar.add(createSidebarHeader(), BorderLayout.NORTH);
        sidebar.add(createNavigationMenu(), BorderLayout.CENTER);
        sidebar.add(createSidebarFooter(), BorderLayout.SOUTH);

        return sidebar;
    }

    private Color getBackgroundColor() {
        return UIManager.getColor("Panel.background");
    }
    
    private Color getTextPrimaryColor() {
        return UIManager.getColor("Label.foreground");
    }
    
    private Color getTextSecondaryColor() {
        return UIManager.getColor("Label.disabledForeground");
    }
    
    private Color getCardBackgroundColor() {
        return UIManager.getColor("Panel.background");
    }
    
    private Color getSeparatorColor() {
        boolean isDark = UIManager.getLookAndFeel().getName().toLowerCase().contains("dark");
        return isDark ? new Color(80, 80, 80) : new Color(230, 230, 230);
    }
    
    private Color getHoverColor() {
        boolean isDark = UIManager.getLookAndFeel().getName().toLowerCase().contains("dark");
        return isDark ? new Color(60, 60, 60) : new Color(240, 240, 240);
    }

    private JPanel createSidebarHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(getBackgroundColor());
        header.setBorder(new EmptyBorder(25, 25, 25, 25));

        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        logoPanel.setBackground(getBackgroundColor());

        JLabel logoIcon = new JLabel("🏥");
        logoIcon.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 32));
        logoIcon.setForeground(PRIMARY_COLOR);
        logoIcon.setBorder(new EmptyBorder(0, 0, 0, 12));

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBackground(getBackgroundColor());

        JLabel titleLabel = new JLabel("MINSA");
        titleLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 24));
        titleLabel.setForeground(getTextPrimaryColor());

        JLabel subtitleLabel = new JLabel("Gestión de Salud");
        subtitleLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 12));
        subtitleLabel.setForeground(getTextSecondaryColor());

        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        logoPanel.add(logoIcon);
        logoPanel.add(textPanel);

        header.add(logoPanel, BorderLayout.CENTER);

        JSeparator separator = new JSeparator();
        separator.setForeground(getSeparatorColor());
        header.add(separator, BorderLayout.SOUTH);

        return header;
    }

    private JPanel createNavigationMenu() {
        JPanel menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBackground(getBackgroundColor());
        menu.setBorder(new EmptyBorder(10, 0, 10, 0));

        // Módulos principales
        JLabel sectionTitle = new JLabel("MÓDULOS PRINCIPALES");
        sectionTitle.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 11));
        sectionTitle.setForeground(getTextSecondaryColor());
        sectionTitle.setBorder(new EmptyBorder(15, 25, 10, 25));
        menu.add(sectionTitle);

        // Crear botones dinámicamente basados en los permisos del rol
        if (hasAccess("inicio")) {
            menu.add(createNavButton("Inicio", "🏠", "inicio", true));
        }
        
        if (hasAccess("usuarios")) {
            menu.add(createNavButton("Usuarios", "👤", "usuarios", false));
        }
        
        if (hasAccess("programas")) {
            menu.add(createNavButton("Programas", "📋", "programas", false));
        }
        
        if (hasAccess("atenciones")) {
            menu.add(createNavButton("Atenciones", "💉", "atenciones", false));
        }
        
        if (hasAccess("reportes")) {
            menu.add(createNavButton("Reportes", "📊", "reportes", false));
        }

        // Separador
        menu.add(Box.createVerticalStrut(20));
        JSeparator separator = new JSeparator();
        separator.setForeground(getSeparatorColor());
        separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        menu.add(separator);
        menu.add(Box.createVerticalStrut(10));

        // Configuración
        JLabel configTitle = new JLabel("CONFIGURACIÓN");
        configTitle.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 11));
        configTitle.setForeground(getTextSecondaryColor());
        configTitle.setBorder(new EmptyBorder(10, 25, 10, 25));
        menu.add(configTitle);

        if (hasAccess("configuracion")) {
            menu.add(createNavButton("Configuración", "⚙️", "configuracion", false));
        }

        menu.add(Box.createVerticalGlue());

        return menu;
    }

    private boolean hasAccess(String url) {
        return roleAccessMap.containsKey(url);
    }

    private JButton createNavButton(String text, String icon, String view, boolean isSelected) {
        JButton button = new JButton();
        button.setLayout(new BorderLayout());
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, UIScale.scale(48)));
        button.setPreferredSize(new Dimension(280, UIScale.scale(48)));
        button.setBorder(new EmptyBorder(0, 25, 0, 25));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setHorizontalAlignment(SwingConstants.LEFT);

        JPanel buttonContent = new JPanel(new BorderLayout());
        buttonContent.setOpaque(false);

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 18));
        iconLabel.setPreferredSize(new Dimension(30, 30));
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel textLabel = new JLabel(text);
        textLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 14));
        textLabel.setBorder(new EmptyBorder(0, 15, 0, 0));

        buttonContent.add(iconLabel, BorderLayout.WEST);
        buttonContent.add(textLabel, BorderLayout.CENTER);

        button.add(buttonContent, BorderLayout.CENTER);

        updateButtonAppearance(button, iconLabel, textLabel, isSelected);

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (button != currentSelectedButton) {
                    button.setBackground(getHoverColor());
                    button.setOpaque(true);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (button != currentSelectedButton) {
                    button.setOpaque(false);
                }
            }
        });

        button.addActionListener(e -> {
            selectNavButton(button, iconLabel, textLabel);
            showView(view);
            updateHeader(text, getViewBreadcrumb(text));
        });

        if (isSelected) {
            currentSelectedButton = button;
        }

        return button;
    }

    private void updateButtonAppearance(JButton button, JLabel iconLabel, JLabel textLabel, boolean isSelected) {
        if (isSelected) {
            button.setBackground(new Color(PRIMARY_COLOR.getRed(), PRIMARY_COLOR.getGreen(), PRIMARY_COLOR.getBlue(), 50));
            button.setOpaque(true);
            iconLabel.setForeground(PRIMARY_COLOR);
            textLabel.setForeground(PRIMARY_COLOR);
            textLabel.setFont(textLabel.getFont().deriveFont(Font.BOLD));
        } else {
            button.setOpaque(false);
            iconLabel.setForeground(getTextSecondaryColor());
            textLabel.setForeground(getTextPrimaryColor());
            textLabel.setFont(textLabel.getFont().deriveFont(Font.PLAIN));
        }
    }

    private void selectNavButton(JButton button, JLabel iconLabel, JLabel textLabel) {
        if (currentSelectedButton != null) {
            Component[] components = ((JPanel) currentSelectedButton.getComponent(0)).getComponents();
            JLabel oldIcon = (JLabel) components[0];
            JLabel oldText = (JLabel) components[1];
            updateButtonAppearance(currentSelectedButton, oldIcon, oldText, false);
        }

        currentSelectedButton = button;
        updateButtonAppearance(button, iconLabel, textLabel, true);
    }

    private JPanel createSidebarFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(getBackgroundColor());
        footer.setBorder(new EmptyBorder(20, 25, 25, 25));

        // Información del usuario
        JPanel userInfo = new JPanel(new BorderLayout());
        userInfo.setBackground(getCardBackgroundColor());
        userInfo.setBorder(new EmptyBorder(15, 15, 15, 15));
        userInfo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(getSeparatorColor(), 1),
            new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel userIcon = new JLabel("👤");
        userIcon.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 20));
        userIcon.setForeground(PRIMARY_COLOR);

        JPanel userText = new JPanel();
        userText.setLayout(new BoxLayout(userText, BoxLayout.Y_AXIS));
        userText.setBackground(getCardBackgroundColor());
        userText.setBorder(new EmptyBorder(0, 10, 0, 0));

        JLabel userName = new JLabel(currentUserName);
        userName.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 13));
        userName.setForeground(getTextPrimaryColor());

        JLabel userRole = userRoleLabel;
        userRole.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 11));
        userRole.setForeground(getTextSecondaryColor());

        userText.add(userName);
        userText.add(userRole);

        userInfo.add(userIcon, BorderLayout.WEST);
        userInfo.add(userText, BorderLayout.CENTER);

        footer.add(userInfo, BorderLayout.NORTH);

        // Botón de cerrar sesión
        JButton logoutButton = new JButton("Cerrar Sesión");
        logoutButton.setBackground(new Color(244, 67, 54));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 13));
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(new EmptyBorder(12, 20, 12, 20));
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutButton.addActionListener(e -> {
            int result = JOptionPane.showConfirmDialog(this, 
                "¿Está seguro que desea cerrar sesión?", 
                "Confirmar", 
                JOptionPane.YES_NO_OPTION);
            if (result == JOptionPane.YES_OPTION) {
                new Login().setVisible(true);
                this.dispose();
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(getBackgroundColor());
        buttonPanel.setBorder(new EmptyBorder(15, 0, 0, 0));
        buttonPanel.add(logoutButton);

        footer.add(buttonPanel, BorderLayout.SOUTH);

        return footer;
    }

    private JPanel createMainContent() {
        JPanel mainContent = new JPanel(new BorderLayout());
        mainContent.setBackground(getBackgroundColor());

        mainContent.add(createHeader(), BorderLayout.NORTH);

        contentPanel.setBackground(getBackgroundColor());
        contentPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainContent.add(contentPanel, BorderLayout.CENTER);

        return mainContent;
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(getCardBackgroundColor());
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, getSeparatorColor()),
            new EmptyBorder(20, 25, 20, 25)
        ));

        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(getCardBackgroundColor());

        headerTitle = new JLabel("Inicio");
        headerTitle.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 28));
        headerTitle.setForeground(getTextPrimaryColor());

        breadcrumbLabel = new JLabel("Inicio");
        breadcrumbLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 13));
        breadcrumbLabel.setForeground(getTextSecondaryColor());

        leftPanel.add(headerTitle);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(breadcrumbLabel);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setBackground(getCardBackgroundColor());

        JLabel dateLabel = new JLabel("Hoy: " + java.time.LocalDate.now().toString());
        dateLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 13));
        dateLabel.setForeground(getTextSecondaryColor());

        rightPanel.add(new NotificacionView());
        rightPanel.add(Box.createHorizontalStrut(15));
        rightPanel.add(dateLabel);

        header.add(leftPanel, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);

        return header;
    }

    private void setupViews() {
        // Solo agregar las vistas a las que el usuario tiene acceso
        if (hasAccess("inicio")) {
            contentPanel.add(new InicioView(), "inicio");
        }
        
        if (hasAccess("usuarios")) {
            contentPanel.add(new UsuarioView(), "usuarios");
        }
        
        if (hasAccess("programas")) {
            contentPanel.add(new ProgramaView(), "programas");
        }
        
        if (hasAccess("atenciones")) {
            contentPanel.add(new AtencionView(), "atenciones");
        }
        
        if (hasAccess("reportes")) {
            contentPanel.add(new ReportesView(), "reportes");
        }
        
        if (hasAccess("configuracion")) {
            contentPanel.add(new ConfiguracionPanel(), "configuracion");
        }
    }

    private void showView(String viewName) {
        if (hasAccess(viewName)) {
            cardLayout.show(contentPanel, viewName);
        } else {
            JOptionPane.showMessageDialog(this, 
                "No tiene permisos para acceder a esta sección", 
                "Acceso denegado", 
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void updateHeader(String title, String breadcrumb) {
        headerTitle.setText(title);
        breadcrumbLabel.setText(breadcrumb);
    }

    private String getViewBreadcrumb(String text) {
        return "Inicio > " + text;
    }

    private void setDefaultView() {
        // Mostrar la primera vista disponible
        if (hasAccess("inicio")) {
            showView("inicio");
            updateHeader("Inicio", "Inicio");
        } else if (hasAccess("usuarios")) {
            showView("usuarios");
            updateHeader("Usuarios", "Inicio > Usuarios");
        } else if (hasAccess("programas")) {
            showView("programas");
            updateHeader("Programas", "Inicio > Programas");
        } else if (hasAccess("atenciones")) {
            showView("atenciones");
            updateHeader("Atenciones", "Inicio > Atenciones");
        } else if (hasAccess("reportes")) {
            showView("reportes");
            updateHeader("Reportes", "Inicio > Reportes");
        } else if (hasAccess("configuracion")) {
            showView("configuracion");
            updateHeader("Configuración", "Inicio > Configuración");
        }
    }
}
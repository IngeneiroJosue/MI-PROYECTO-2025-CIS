/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author LEnovo
 */
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.fonts.roboto.FlatRobotoFont;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class FormularioAtencion extends JPanel {

    public FormularioAtencion() {
        // Configuración de FlatLaf (solo debe ejecutarse una vez en la aplicación)
        FlatRobotoFont.install();
        FlatLightLaf.setup();
        UIManager.put("defaultFont", new Font(FlatRobotoFont.FAMILY, Font.PLAIN, 13));

        this.setLayout(new BorderLayout(10, 10));
        this.setBorder(new EmptyBorder(15, 15, 15, 15));

        // Encabezado Minsa
        JPanel headerPanel = crearHeaderMinsa();
        this.add(headerPanel, BorderLayout.NORTH);

        // Formulario con scroll
        JPanel formPanel = crearFormularioAtencion();
        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        this.add(scrollPane, BorderLayout.CENTER);

        // Botones
        JPanel buttonPanel = crearPanelBotones();
        this.add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel crearHeaderMinsa() {
        JPanel panel = new JPanel(new GridLayout(3, 1));
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.RED));

        JLabel minsaLabel = new JLabel("MINISTERIO DE SALUD", JLabel.CENTER);
        minsaLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 18));
        minsaLabel.setForeground(Color.RED);

        JLabel sistemaLabel = new JLabel("SIS/ESSALUD", JLabel.CENTER);
        sistemaLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 16));

        JLabel obstetriciaLabel = new JLabel("DPTO. OBSTETRICIA", JLabel.CENTER);
        obstetriciaLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 14));

        panel.add(minsaLabel);
        panel.add(sistemaLabel);
        panel.add(obstetriciaLabel);

        return panel;
    }

    private JPanel crearFormularioAtencion() {
        JPanel panel = new JPanel(new BorderLayout(10, 15));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Panel superior
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Fecha
        JLabel fechaLabel = new JLabel("Fecha:");
        fechaLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 13));
        JTextField fechaField = new JTextField(10);
        fechaField.putClientProperty("JTextField.placeholderText", "dd/mm/aaaa");

        gbc.gridx = 0; gbc.gridy = 0;
        topPanel.add(fechaLabel, gbc);
        gbc.gridx = 1;
        topPanel.add(fechaField, gbc);

        // Título paciente
        JLabel pacienteLabel = new JLabel("Paciente");
        pacienteLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 14));
        pacienteLabel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        topPanel.add(pacienteLabel, gbc);
        gbc.gridwidth = 1;

        // Campos del paciente
        agregarCampoPaciente(topPanel, gbc, 2, "DNI:", new JTextField(8));
        agregarCampoPaciente(topPanel, gbc, 3, "Nombres:", new JTextField(20));
        agregarCampoPaciente(topPanel, gbc, 4, "Apellidos:", new JTextField(20));
        agregarCampoPaciente(topPanel, gbc, 5, "Edad:", new JTextField(3));

        JComboBox<String> generoCombo = new JComboBox<>(new String[]{"Masculino", "Femenino", "Otro"});
        agregarCampoPaciente(topPanel, gbc, 6, "Género:", generoCombo);

        JComboBox<String> sangreCombo = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
        agregarCampoPaciente(topPanel, gbc, 7, "Tipo Sanguíneo:", sangreCombo);

        panel.add(topPanel, BorderLayout.NORTH);

        // Panel central
        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbcCenter = new GridBagConstraints();
        gbcCenter.insets = new Insets(5, 5, 5, 5);
        gbcCenter.anchor = GridBagConstraints.WEST;
        gbcCenter.fill = GridBagConstraints.HORIZONTAL;

        JLabel atencionLabel = new JLabel("Atención/Cita");
        atencionLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 14));
        atencionLabel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
        gbcCenter.gridx = 0; gbcCenter.gridy = 0; gbcCenter.gridwidth = 2;
        centerPanel.add(atencionLabel, gbcCenter);
        gbcCenter.gridwidth = 1;

        agregarCampoAtencion(centerPanel, gbcCenter, 1, "Obstetra:", new JTextField(25));

        JComboBox<String> programaCombo = new JComboBox<>(new String[]{"CANCER", "VIH", "TUBERCULOSIS", "DIABETES"});
        agregarCampoAtencion(centerPanel, gbcCenter, 2, "Programa:", programaCombo);

        JComboBox<String> tipoConsultaCombo = new JComboBox<>(new String[]{"PREVENCIÓN", "TRATAMIENTO", "SEGUIMIENTO"});
        agregarCampoAtencion(centerPanel, gbcCenter, 3, "Tipo de Consulta:", tipoConsultaCombo);

        JLabel obsLabel = new JLabel("Observación:");
        obsLabel.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 13));
        JTextArea obsArea = new JTextArea(5, 30);
        obsArea.setLineWrap(true);
        obsArea.setWrapStyleWord(true);
        JScrollPane obsScroll = new JScrollPane(obsArea);

        gbcCenter.gridx = 0; gbcCenter.gridy = 4;
        centerPanel.add(obsLabel, gbcCenter);
        gbcCenter.gridx = 1;
        centerPanel.add(obsScroll, gbcCenter);

        panel.add(centerPanel, BorderLayout.CENTER);

        return panel;
    }

    private void agregarCampoPaciente(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent component) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 13));

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(lbl, gbc);
        gbc.gridx = 1;
        panel.add(component, gbc);
    }

    private void agregarCampoAtencion(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent component) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 13));

        gbc.gridx = 0; gbc.gridy = row;
        panel.add(lbl, gbc);
        gbc.gridx = 1;
        panel.add(component, gbc);
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        JButton nuevoBtn = crearBoton("Nuevo", Color.decode("#2196F3"));
        JButton editarBtn = crearBoton("Editar", Color.decode("#FFC107"));
        JButton guardarBtn = crearBoton("Guardar", Color.decode("#4CAF50"));
        JButton cerrarBtn = crearBoton("Cerrar", Color.decode("#F44336"));

        panel.add(nuevoBtn);
        panel.add(editarBtn);
        panel.add(guardarBtn);
        panel.add(cerrarBtn);

        return panel;
    }

    private JButton crearBoton(String texto, Color color) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font(FlatRobotoFont.FAMILY, Font.BOLD, 13));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.setPreferredSize(new Dimension(100, 35));
        return boton;
    }
    
   
}

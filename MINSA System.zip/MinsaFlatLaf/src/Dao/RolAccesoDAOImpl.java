package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Usuario
 */
public class RolAccesoDAOImpl implements RolAccesoDAO {

    public String obtenerNombreRol(int idRol, Connection conexion) {
        String nombreRol = null;
        
        try {
            String query = "SELECT NombreRol FROM Rol WHERE idRol = ?";
            PreparedStatement pst = conexion.prepareStatement(query);
            pst.setInt(1, idRol);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                nombreRol = rs.getString("NombreRol");
            }
            
            rs.close();
            pst.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return nombreRol;
    }

   
    
    public Map<String, List<String>> obtenerAccesoPorRol(int idRol, Connection conexion) {
        Map<String, List<String>> accesos = new HashMap<>();
        
        try {
            String query = "SELECT o.NombreOpcion, o.Url FROM Acceso a " +
                         "JOIN Opcion o ON a.idOpcion = o.idOpcion " +
                         "WHERE a.idRol = ? AND a.Estado = 1";
            
            PreparedStatement pst = conexion.prepareStatement(query);
            pst.setInt(1, idRol);
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                String optionName = rs.getString("NombreOpcion");
                String url = rs.getString("Url");
                
                if (!accesos.containsKey(url)) {
                    accesos.put(url, new ArrayList<>());
                }
                accesos.get(url).add(optionName);
            }
            
            rs.close();
            pst.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return accesos;
    }
    }
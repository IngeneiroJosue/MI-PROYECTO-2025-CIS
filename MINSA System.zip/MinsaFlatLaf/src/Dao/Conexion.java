/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author LEnovo
 */
public class Conexion {
    Connection conectar = null;
    
    String usuario = "joed";
    String contraseña = "joed123";
    String bd = "Minsa";
    String ip = "localhost";
    String puerto = "1433";

    String cadena = "jdbc:sqlserver://" + ip + ":" + puerto + ";databaseName=" + bd;

    public  Connection establecerConexion() {
        try {
            String cadena = "jdbc:sqlserver://"+ ip +":"+puerto+";databaseName=" + bd  + ";encrypt=true;trustServerCertificate=true";
            conectar = DriverManager.getConnection(cadena, usuario, contraseña);
            System.out.println("¡Conexión exitosa!");
                   
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar: " + e.getMessage());
        }
        return conectar;
    }
}

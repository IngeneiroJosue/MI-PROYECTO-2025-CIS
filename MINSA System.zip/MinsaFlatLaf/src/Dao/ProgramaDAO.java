/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Dao;

/**
 *
 * @author LEnovo
 */
import Modelo.Programa;
import java.util.List;

public interface ProgramaDAO {
    List<Programa> listarActivos();
    void registrar(Programa programa);
    void actualizar(Programa programa);
    void eliminar(int idPrograma); // Cambio de estado a 2
    Programa obtenerPorId(int idPrograma);
}

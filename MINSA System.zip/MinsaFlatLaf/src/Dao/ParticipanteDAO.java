/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author LEnovo
 */
import Modelo.Participante;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParticipanteDAO {

    private Connection con;

    public List<Participante> listar() {
        List<Participante> lista = new ArrayList<>();
        String sql = "SELECT * FROM Participante";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Participante p = new Participante();
                p.setIdParticipante(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setApellido(rs.getString("apellido"));
                p.setDni(rs.getString("dni"));
                p.setTelefono(rs.getString("telefono"));
                p.setCorreo(rs.getString("correo"));
                p.setSexo(rs.getString("sexo"));
                p.setTipoSanguineo(rs.getString("tipo_sanguineo"));
                p.setEdad(rs.getInt("edad"));
                lista.add(p);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public Participante obtenerPorId(int id) {
        String sql = "SELECT * FROM Participante WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Participante p = new Participante();
                p.setIdParticipante(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setApellido(rs.getString("apellido"));
                p.setDni(rs.getString("dni"));
                p.setTelefono(rs.getString("telefono"));
                p.setCorreo(rs.getString("correo"));
                p.setSexo(rs.getString("sexo"));
                p.setTipoSanguineo(rs.getString("tipo_sanguineo"));
                p.setEdad(rs.getInt("edad"));
                return p;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean agregar(Participante p) {
        String sql = "INSERT INTO Participante (nombre, apellido, dni, telefono, correo, sexo, tipo_sanguineo, edad) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getApellido());
            ps.setString(3, p.getDni());
            ps.setString(4, p.getTelefono());
            ps.setString(5, p.getCorreo());
            ps.setString(6, p.getSexo());
            ps.setString(7, p.getTipoSanguineo());
            ps.setInt(8, p.getEdad());

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean actualizar(Participante p) {
        String sql = "UPDATE Participante SET nombre = ?, apellido = ?, dni = ?, telefono = ?, correo = ?, sexo = ?, tipo_sanguineo = ?, edad = ? WHERE id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getApellido());
            ps.setString(3, p.getDni());
            ps.setString(4, p.getTelefono());
            ps.setString(5, p.getCorreo());
            ps.setString(6, p.getSexo());
            ps.setString(7, p.getTipoSanguineo());
            ps.setInt(8, p.getEdad());
            ps.setInt(9, p.getIdParticipante());

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean eliminar(int id) {
        String sql = "Update Participante SET estado=2 WHERE id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}


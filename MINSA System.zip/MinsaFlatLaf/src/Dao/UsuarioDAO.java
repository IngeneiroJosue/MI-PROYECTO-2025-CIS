/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Modelo.Usuario;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author LEnovo
 */
public class UsuarioDAO {
    Conexion con = new Conexion();
    
    public boolean registrarUsuario(Usuario usuario) {
    String query = "{CALL AñadirUsuario(?, ?, ?, ?, ?)}";

    try (Connection conn = con.establecerConexion();
         CallableStatement stmt = conn.prepareCall(query)) {

        // Asignar parámetros al procedimiento
        stmt.setInt(1, usuario.getIdParticipante());
        stmt.setInt(2, usuario.getIdRol());
        stmt.setString(3, usuario.getUsuario()); // Nombre de usuario
        stmt.setString(4, usuario.getClave()); // Contraseña en texto plano
        stmt.setInt(5, usuario.getEstado()); // Estado (0, 1, 2)

        int filasAfectadas = stmt.executeUpdate();
        return filasAfectadas > 0;

    } catch (SQLException e) {
        System.err.println("Error al insertar usuario: " + e.getMessage());
        return false;
    }
}

  

    
    
public int validarCredenciales(String username, String password) {
    Connection connection = con.establecerConexion();

    if (connection == null) {
        throw new RuntimeException("No se pudo establecer la conexión a la base de datos.");
    }

    String sql = "{CALL ValidarCredenciales(?, ?, ?, ?)}";

    try (CallableStatement callableStatement = connection.prepareCall(sql)) {
        // Parámetros de entrada
        callableStatement.setString(1, username);
        callableStatement.setString(2, password);

        // Parámetros de salida
        callableStatement.registerOutParameter(3, Types.VARCHAR); // Nombre del Obstetra
        callableStatement.registerOutParameter(4, Types.INTEGER); // ID del Usuario

        // Ejecutar procedimiento almacenado
        callableStatement.execute();

        String nombreObstetra = callableStatement.getString(3);
        int idUsuario = callableStatement.getInt(4);

        if (nombreObstetra != null && idUsuario > 0) {
            return idUsuario; // Devolver nombre si credenciales son válidas
        } else {
            return -1; // Credenciales inválidas
        }

    } catch (SQLException e) {
        throw new RuntimeException("Error al validar credenciales: " + e.getMessage(), e);
    } finally {
        try {
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
public int obtenerIdUsuarioPorCorreoYDNI(String correo, String dni) {
    int idUsuario = -1;
    String sql = "{CALL ValidarUsuarioCorreoDNI(?, ?, ?)}";

    try (Connection conn = con.establecerConexion();
         CallableStatement stmt = conn.prepareCall(sql)) {

        stmt.setString(1, correo);
        stmt.setString(2, dni);
        stmt.registerOutParameter(3, Types.INTEGER);

        stmt.execute();

        idUsuario = stmt.getInt(3);

        if (stmt.wasNull()) {
            idUsuario = -1; // No encontrado
        }
    } catch (SQLException e) {
        System.err.println("Error al validar usuario: " + e.getMessage());
    }

    return idUsuario;
}
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author LEnovo
 */
import Modelo.Programa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProgramaDAOImpl implements ProgramaDAO {

    private final Connection conn;

    public ProgramaDAOImpl(Connection conn) {
        this.conn = conn;
    }

    public List<Programa> listarActivos() {
        List<Programa> lista = new ArrayList<>();
        String sql = "SELECT * FROM Programa WHERE Estado = 1";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Programa p = new Programa();
                p.setIdPrograma(rs.getInt("idPrograma"));
                p.setNombrePrograma(rs.getString("NombrePrograma"));
                p.setMeta(rs.getInt("Meta"));
                p.setAño(rs.getInt("Año"));
                p.setEstado(rs.getInt("Estado"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public void registrar(Programa programa) {
        String sql = "INSERT INTO Programa (NombrePrograma, Meta, Año, Estado) VALUES (?, ?, ?, 1)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, programa.getNombrePrograma());
            ps.setInt(2, programa.getMeta());
            ps.setInt(3, programa.getAño());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void actualizar(Programa programa) {
        String sql = "UPDATE Programa SET NombrePrograma = ?, Meta = ?, Año = ? WHERE idPrograma = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, programa.getNombrePrograma());
            ps.setInt(2, programa.getMeta());
            ps.setInt(3, programa.getAño());
            ps.setInt(4, programa.getIdPrograma());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int idPrograma) {
        String sql = "UPDATE Programa SET Estado = 2 WHERE idPrograma = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idPrograma);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Programa obtenerPorId(int idPrograma) {
        String sql = "SELECT * FROM Programa WHERE idPrograma = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idPrograma);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Programa p = new Programa();
                    p.setIdPrograma(rs.getInt("idPrograma"));
                    p.setNombrePrograma(rs.getString("NombrePrograma"));
                    p.setMeta(rs.getInt("Meta"));
                    p.setAño(rs.getInt("Año"));
                    p.setEstado(rs.getInt("Estado"));
                    return p;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}

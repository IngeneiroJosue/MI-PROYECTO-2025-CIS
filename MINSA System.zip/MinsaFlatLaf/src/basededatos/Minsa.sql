-- Crear base de datos
CREATE DATABASE MinsaBD;
GO

USE MinsaBD;
GO

-- Tabla Rol
CREATE TABLE Rol (
    idRol INT PRIMARY KEY IDENTITY(1,1),
    NombreRol VARCHAR(50) NOT NULL,
    PermiteUsuario BIT NOT NULL DEFAULT 0
);
GO

-- Tabla Participante
CREATE TABLE Participante (
    idParticipante INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL,
    Apellido VARCHAR(50) NOT NULL,
    DNI CHAR(8) NOT NULL UNIQUE,
    Telefono CHAR(9) NOT NULL,
    Correo VARCHAR(50) NOT NULL UNIQUE,
    Sexo CHAR(1) NULL,
    TipoSanguineo VARCHAR(3) NULL,
    FechaDeNacimiento DATE NULL,
    Edad AS DATEDIFF(YEAR, FechaDeNacimiento, GETDATE()) 
);
GO

-- Tabla Usuario
CREATE TABLE Usuario (
    idUsuario INT PRIMARY KEY IDENTITY(1,1),
    idParticipante INT NOT NULL,
    idRol INT NOT NULL,
    Usuario VARCHAR(50) NOT NULL UNIQUE,
    Contraseña VARBINARY(32) NOT NULL, -- SHA2_256
    Estado TINYINT NOT NULL CHECK (Estado IN (0,1,2)),
    FOREIGN KEY (idParticipante) REFERENCES Participante(idParticipante),
    FOREIGN KEY (idRol) REFERENCES Rol(idRol)
);
GO

-- Tabla Programa
CREATE TABLE Programa (
    idPrograma INT PRIMARY KEY IDENTITY(1,1),
    NombrePrograma VARCHAR(100) NOT NULL,
    Meta INT NULL,
    Año INT NULL,
    Estado TINYINT NOT NULL CHECK (Estado IN (0,1,2)),
);
GO

-- Tabla Atencion
CREATE TABLE Atencion (
    idAtencion INT PRIMARY KEY IDENTITY(1,1),
    idParticipante INT NOT NULL,
	idUsuario INT NOT NULL,
    Observacion TEXT NULL,
    Fecha DATE NOT NULL,
    FOREIGN KEY (idParticipante) REFERENCES Participante(idParticipante),
	FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario)
);
GO

-- Tabla Opcion
CREATE TABLE Opcion (
    idOpcion INT PRIMARY KEY IDENTITY(1,1),
    NombreOpcion VARCHAR(100) NOT NULL,
    Url VARCHAR(50) NOT NULL UNIQUE,
    Icono VARCHAR(50) NULL
);
GO

-- Tabla Acceso
CREATE TABLE Acceso (
    idAcceso INT PRIMARY KEY IDENTITY(1,1),
    idRol INT NOT NULL,
    idOpcion INT NOT NULL,
    Estado BIT NOT NULL DEFAULT 1,
    FOREIGN KEY (idRol) REFERENCES Rol(idRol),
    FOREIGN KEY (idOpcion) REFERENCES Opcion(idOpcion)
);
GO

-- Insertar Roles
INSERT INTO Rol (NombreRol, PermiteUsuario) VALUES
('Administrador', 1),
('Obstetra', 1),
('Jefa de Obstetricia', 1),
('Paciente', 0);
GO

-- Insertar Participantes
INSERT INTO Participante (Nombre, Apellido, DNI, Telefono, Correo, Sexo, TipoSanguineo, FechaDeNacimiento)
VALUES 
('Ana', 'Gonzales', '12345678', '987654321', 'ana@gmail.com', 'F', 'O+', '1990-03-12'),
('Luis', 'Paredes', '87654321', '912345678', 'luisp@gmail.com', 'M', 'A-', '1985-08-25');
GO

-- Insertar Usuario (contraseña: 'admin123')
INSERT INTO Usuario (idParticipante, idRol, Usuario, Contraseña, Estado)
VALUES 
(1, 1, 'admin', HASHBYTES('SHA2_256', CONVERT(VARBINARY(50), 'admin123')), 1);
GO

-- Insertar Programas
INSERT INTO Programa (NombrePrograma, Meta, Año, Estado) VALUES
('Programa de Atención Integral', 100, 2025, 1),
('Plan Materno Infantil', 80, 2025, 1);
GO

-- Insertar Atenciones
INSERT INTO Atencion (idParticipante, Observacion, Fecha)
VALUES 
(1, 'Consulta inicial', GETDATE(), 2 ),
(2, 'Control mensual', GETDATE(), 2 );
GO

-- Insertar Opciones
INSERT INTO Opcion (NombreOpcion, Url, Icono) VALUES
('Inicio', 'inicio', 'home'),
('Usuarios', 'usuarios', 'users'),
('Programas', 'programas', 'programs'),
('Atenciones', 'atenciones', 'calendar'),
('Reportes', 'reportes', 'chart'),
('Configuración', 'configuracion', 'settings');
GO


INSERT INTO Acceso (idRol, idOpcion, Estado) VALUES
(1, 1, 1), -- Inicio
(1, 2, 1), -- Usuarios
(1, 3, 1), -- Programas
(1, 4, 1), -- Atenciones
(1, 5, 1), -- Reportes
(1, 6, 1); -- Configuración
(2, 1, 1), -- Inicio
(2, 2, 1), -- Usuarios
(2, 3, 1), -- Programas
(2, 4, 1), -- Atenciones
(2, 5, 1), -- Reportes
(3, 1, 1), -- Inicio
(3, 4, 1), -- Atenciones



GO



-- Procedimiento para añadir usuario con validación del rol que permite usuario
CREATE PROCEDURE AñadirUsuario
    @idParticipante INT,
    @idRol INT,
    @Usuario VARCHAR(50),
    @Contraseña VARCHAR(50),
    @Estado TINYINT
AS
BEGIN
    SET NOCOUNT ON;

    -- Validar si el rol permite usuario
    IF NOT EXISTS (SELECT 1 FROM Rol WHERE idRol = @idRol AND PermiteUsuario = 1)
    BEGIN
        RAISERROR('El rol no tiene permiso para tener usuario.', 16, 1);
        RETURN;
    END

    -- Hashear la contraseña con SHA2_256
    DECLARE @HashedPassword VARBINARY(32);
    SET @HashedPassword = HASHBYTES('SHA2_256', CONVERT(VARBINARY(50), @Contraseña));

    -- Insertar usuario
    INSERT INTO Usuario (idParticipante, idRol, Usuario, Contraseña, Estado)
    VALUES (@idParticipante, @idRol, @Usuario, @HashedPassword, @Estado);
END
GO

-- Procedimiento para validar credenciales
CREATE PROCEDURE ValidarCredenciales
    @Usuario VARCHAR(50),
    @Contraseña VARCHAR(50),
    @NombreParticipante VARCHAR(100) OUTPUT,
    @idUsuario INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @HashedPassword VARBINARY(32);
    SET @HashedPassword = HASHBYTES('SHA2_256', CONVERT(VARBINARY(50), @Contraseña));

    SELECT TOP 1 
        @NombreParticipante = CONCAT(p.Nombre, ' ', p.Apellido),
        @idUsuario = u.idUsuario
    FROM Usuario u
    INNER JOIN Participante p ON u.idParticipante = p.idParticipante
    WHERE u.Usuario = @Usuario
      AND u.Contraseña = @HashedPassword
      AND u.Estado = 1;
END
GO

-- Procedimiento para actualizar contraseña
CREATE PROCEDURE ActualizarContraseña
    @idUsuario INT,
    @NuevaContraseña VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @HashedPassword VARBINARY(32);
    SET @HashedPassword = HASHBYTES('SHA2_256', CONVERT(VARBINARY(50), @NuevaContraseña));

    UPDATE Usuario
    SET Contraseña = @HashedPassword
    WHERE idUsuario = @idUsuario;
END
GO

-- Procedimiento para validar si existe usuario con correo y DNI
CREATE PROCEDURE ValidarUsuarioCorreoDNI
    @Correo VARCHAR(50),
    @DNI CHAR(8),
    @idUsuario INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP 1 @idUsuario = u.idUsuario
    FROM Usuario u
    INNER JOIN Participante p ON u.idParticipante = p.idParticipante
    WHERE p.Correo = @Correo AND p.DNI = @DNI;
END
GO


GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO joed;


SELECT*FROM PROGRAMA


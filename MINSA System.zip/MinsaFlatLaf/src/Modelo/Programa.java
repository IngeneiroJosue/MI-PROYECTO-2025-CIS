/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author LEnovo
 */


public class Programa {
    private int idPrograma;
    private String nombrePrograma;
    private int meta;
    private int año;
    private int estado;

    // Getters y setters
    public int getIdPrograma() { return idPrograma; }
    public void setIdPrograma(int idPrograma) { this.idPrograma = idPrograma; }
    public String getNombrePrograma() { return nombrePrograma; }
    public void setNombrePrograma(String nombrePrograma) { this.nombrePrograma = nombrePrograma; }
    public int getMeta() { return meta; }
    public void setMeta(int meta) { this.meta = meta; }
    public int getAño() { return año; }
    public void setAño(int año) { this.año = año; }
    public void setEstado(int estado) {this.estado = estado;}
    public int getEstado() {return estado; }
}
